# LOVRA Notification Backend

Production-ready, minimal and secure gateway for dispatching event notifications to Telegram administrators without exposing any bot credentials in client Android builds.

## Setup Instructions

1. Install dependencies:
   ```bash
   cd backend
   npm install
   ```

2. Configure Environment Secrets:
   Copy `.env.example` to `.env`:
   ```bash
   cp .env.example .env
   ```
   Fill in your server-side secrets:
   ```env
   TELEGRAM_BOT_TOKEN="YOUR_NEW_REVOKED_BOT_TOKEN"
   TELEGRAM_ADMIN_CHAT_ID="YOUR_ADMIN_CHAT_ID"
   LOVRA_CLIENT_SECRET="OPTIONAL_SHARED_SECRET"
   PORT=8080
   ```

3. Start server:
   ```bash
   npm start
   ```

4. Deploy to free/minimal cloud hosts:
   - Google Cloud Run (Container)
   - Render.com / Railway.app
   - Vercel Serverless Function / Firebase Cloud Functions
