/**
 * LOVRA Creator Network - Secure Server-Side Notification Gateway
 *
 * Implements:
 * - Server-side secret storage (TELEGRAM_BOT_TOKEN, TELEGRAM_ADMIN_CHAT_ID)
 * - Request validation & input sanitization
 * - Rate limiting & anti-abuse protection
 * - HTTPS / Secure Header enforcement
 * - Strictly isolates Telegram Bot tokens away from Android client APK
 */

require('dotenv').config();
const express = require('express');
const cors = require('cors');
const rateLimit = require('express-rate-limit');

const app = express();
const PORT = process.env.PORT || 8080;

// Read server-side environment variables ONLY
const TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
const TELEGRAM_ADMIN_CHAT_ID = process.env.TELEGRAM_ADMIN_CHAT_ID;
const LOVRA_CLIENT_SECRET = process.env.LOVRA_CLIENT_SECRET;

app.use(express.json({ limit: '64kb' }));
app.use(cors());

// Anti-Abuse Rate Limiting: max 60 requests per 15 minutes per IP
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 60,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many notification requests. Please try again later.' }
});

app.use('/api/', apiLimiter);

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    service: 'lovra-notification-gateway',
    configured: Boolean(TELEGRAM_BOT_TOKEN && TELEGRAM_ADMIN_CHAT_ID)
  });
});

/**
 * POST /api/telegram/notify
 * Accepts structured event notifications from LOVRA Android app and securely
 * dispatches them to Telegram using server-side secrets.
 */
app.post('/api/telegram/notify', async (req, res) => {
  try {
    // 1. Optional client authorization header validation
    if (LOVRA_CLIENT_SECRET) {
      const clientKey = req.header('X-Lovra-Client-Key');
      if (clientKey !== LOVRA_CLIENT_SECRET) {
        return res.status(401).json({ error: 'Unauthorized notification request' });
      }
    }

    // 2. Validate Telegram credentials presence on server
    if (!TELEGRAM_BOT_TOKEN || !TELEGRAM_ADMIN_CHAT_ID) {
      console.warn('[LOVRA Gateway] TELEGRAM_BOT_TOKEN or TELEGRAM_ADMIN_CHAT_ID not configured on server.');
      return res.status(503).json({ error: 'Telegram gateway credentials not configured on backend.' });
    }

    // 3. Validate & sanitize payload
    const { event, message, buttons } = req.body;
    if (!message || typeof message !== 'string') {
      return res.status(400).json({ error: 'Missing or invalid "message" string in request body.' });
    }

    const sanitizedMessage = message.slice(0, 4000); // Telegram 4096-char ceiling

    // 4. Build Telegram API request using server-side chat ID (never client-provided chat ID)
    const telegramPayload = {
      chat_id: TELEGRAM_ADMIN_CHAT_ID,
      text: sanitizedMessage,
      parse_mode: 'HTML',
      disable_web_page_preview: true
    };

    if (Array.isArray(buttons) && buttons.length > 0) {
      telegramPayload.reply_markup = {
        inline_keyboard: buttons
      };
    }

    // 5. Secure dispatch to Telegram Bot API
    const response = await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(telegramPayload)
    });

    const responseData = await response.json();

    if (!response.ok || !responseData.ok) {
      console.error('[LOVRA Gateway] Telegram API error:', responseData);
      return res.status(502).json({ error: 'Failed to deliver message to Telegram Bot API', details: responseData });
    }

    return res.status(200).json({ success: true, event: event || 'general' });
  } catch (error) {
    console.error('[LOVRA Gateway] Internal error handling notification:', error);
    return res.status(500).json({ error: 'Internal gateway error' });
  }
});

app.listen(PORT, () => {
  console.log(`[LOVRA Gateway] Secure notification server listening on port ${PORT}`);
});
