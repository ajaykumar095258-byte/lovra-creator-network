package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.CinematicLaunchSplash
import com.example.ui.components.GuestRestrictedPlaceholder
import com.example.ui.components.LovraBottomBar
import com.example.ui.components.LovraTopHeader
import com.example.ui.components.MiniPlayerBar
import com.example.ui.screens.*
import com.example.ui.theme.LovraLightBg
import com.example.ui.theme.LovraPrimary
import com.example.ui.theme.LovraTheme
import com.example.viewmodel.LoginViewModel
import com.example.viewmodel.LovraViewModel
import com.example.viewmodel.Screen

class MainActivity : ComponentActivity() {

    private val loginViewModel: LoginViewModel by viewModels()
    private val viewModel: LovraViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Handle incoming Android App Links / Deep Links
        intent?.data?.toString()?.let { uriStr ->
            viewModel.handleDeepLink(uriStr)
        }

        setContent {
            LovraTheme {
                LovraApp(
                    loginViewModel = loginViewModel,
                    viewModel = viewModel
                )
            }
        }
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        intent.data?.toString()?.let { uriStr ->
            viewModel.handleDeepLink(uriStr)
        }
    }
}

@Composable
fun LovraApp(
    loginViewModel: LoginViewModel,
    viewModel: LovraViewModel
) {
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val playerState by viewModel.playerState.collectAsStateWithLifecycle()
    val toastMessage by viewModel.toastMessage.collectAsStateWithLifecycle()
    val inAppNotification by viewModel.inAppNotification.collectAsStateWithLifecycle()
    val context = LocalContext.current

    // Observe Auth from LoginViewModel
    val authUser by loginViewModel.authUser.collectAsStateWithLifecycle()
    val isLoginGuestMode by loginViewModel.isGuestMode.collectAsStateWithLifecycle()
    val isGuestMode by viewModel.isGuestMode.collectAsStateWithLifecycle()

    // Synchronize ViewModel session whenever authentic user logs in
    LaunchedEffect(authUser) {
        if (authUser != null) {
            viewModel.onAuthSessionChanged(authUser)
        }
    }

    // Synchronize Guest mode state
    LaunchedEffect(isLoginGuestMode) {
        if (isLoginGuestMode && !isGuestMode) {
            viewModel.enterGuestMode()
        }
    }

    // Short cinematic launch splash on app opening (Rule 2 & 3)
    var showSplash by remember { mutableStateOf(true) }

    // Toast feedback
    LaunchedEffect(toastMessage) {
        toastMessage?.let {
            Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
            viewModel.clearToast()
        }
    }

    if (showSplash) {
        CinematicLaunchSplash(
            onFinished = { showSplash = false }
        )
        return
    }

    // ==========================================
    // AUTHENTICATION GATE & GUEST MODE
    // ==========================================
    if (authUser == null && !isGuestMode && !isLoginGuestMode) {
        AuthScreen(
            loginViewModel = loginViewModel,
            onAuthSuccess = { user ->
                viewModel.onAuthSessionChanged(user)
                viewModel.showToast("Welcome to LOVRA, ${user.displayName ?: "Creator"}!")
            },
            onEnterGuestMode = {
                viewModel.enterGuestMode()
                viewModel.showToast("Welcome! Exploring LOVRA in Guest Preview Mode.")
            }
        )
        return
    }

    // System BackHandler handling
    BackHandler(enabled = currentScreen != Screen.Home) {
        viewModel.navigateBack()
    }

    Scaffold(
        containerColor = LovraLightBg,
        topBar = {
            if (currentScreen != Screen.StoryDetail && currentScreen != Screen.MonetizationApply) {
                LovraTopHeader(
                    title = "LOVRA",
                    isGuestMode = isGuestMode,
                    onAdminClick = {
                        if (isGuestMode) {
                            viewModel.showToast("Admin Desk requires authorized sign-in.")
                        } else {
                            viewModel.navigateTo(Screen.AdminDashboard)
                        }
                    },
                    onStudioClick = {
                        if (isGuestMode) {
                            viewModel.showToast("Creator Studio requires Google Sign-In.")
                        } else {
                            viewModel.navigateTo(Screen.CreatorStudio)
                        }
                    },
                    onSignInClick = {
                        loginViewModel.exitGuestMode()
                        viewModel.exitGuestMode()
                    }
                )
            }
        },
        bottomBar = {
            Column {
                // Persistent audio/video mini-player bar if story is loaded
                if (playerState.story != null && currentScreen != Screen.StoryDetail) {
                    MiniPlayerBar(
                        playerState = playerState,
                        onTogglePlay = { viewModel.togglePlayerPlayback() },
                        onExpand = { viewModel.navigateTo(Screen.StoryDetail) }
                    )
                }

                // Global Bottom Navigation Bar (Home, Discover, Create, Messages, Profile)
                LovraBottomBar(
                    currentRoute = currentScreen.route,
                    onNavigate = { route ->
                        when (route) {
                            "home" -> viewModel.navigateTo(Screen.Home)
                            "discover" -> viewModel.navigateTo(Screen.Discover)
                            "create" -> {
                                if (isGuestMode) {
                                    viewModel.showToast("Guest Mode: Publishing stories requires Google Sign-In.")
                                } else {
                                    viewModel.navigateTo(Screen.Create)
                                }
                            }
                            "messages" -> {
                                if (isGuestMode) {
                                    viewModel.showToast("Guest Mode: Chat and community groups require Google Sign-In.")
                                } else {
                                    viewModel.navigateTo(Screen.Messages)
                                }
                            }
                            "profile" -> viewModel.navigateTo(Screen.Profile)
                        }
                    }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(LovraLightBg)
        ) {
            when (currentScreen) {
                Screen.Home -> HomeScreen(viewModel = viewModel)
                Screen.Discover -> DiscoverScreen(viewModel = viewModel)
                Screen.Create -> {
                    if (isGuestMode) {
                        GuestRestrictedPlaceholder(
                            featureTitle = "Creator Studio Publishing",
                            featureDescription = "Publishing audio stories, dramas, anime series, and videos is reserved for registered creators.",
                            onSignInClick = {
                                loginViewModel.exitGuestMode()
                                viewModel.exitGuestMode()
                            }
                        )
                    } else {
                        CreateScreen(viewModel = viewModel)
                    }
                }
                Screen.Messages -> {
                    if (isGuestMode) {
                        GuestRestrictedPlaceholder(
                            featureTitle = "1-to-1 Chat & Creator Guilds",
                            featureDescription = "Direct messaging, private conversations, and creator community groups require Google Sign-In.",
                            onSignInClick = {
                                loginViewModel.exitGuestMode()
                                viewModel.exitGuestMode()
                            }
                        )
                    } else {
                        MessagesScreen(viewModel = viewModel)
                    }
                }
                Screen.Profile -> ProfileScreen(viewModel = viewModel)
                Screen.StoryDetail -> StoryDetailScreen(viewModel = viewModel)
                Screen.MonetizationApply -> {
                    if (isGuestMode) {
                        GuestRestrictedPlaceholder(
                            featureTitle = "Monetize Your Account",
                            featureDescription = "Applying for creator monetization and receiving revenue disbursements requires an authenticated Google account.",
                            onSignInClick = {
                                loginViewModel.exitGuestMode()
                                viewModel.exitGuestMode()
                            }
                        )
                    } else {
                        MonetizationApplyScreen(viewModel = viewModel)
                    }
                }
                Screen.CreatorStudio -> {
                    if (isGuestMode) {
                        GuestRestrictedPlaceholder(
                            featureTitle = "Creator Earnings & Ledger",
                            featureDescription = "Tracking qualified view earnings and requesting payouts requires an authenticated account.",
                            onSignInClick = {
                                loginViewModel.exitGuestMode()
                                viewModel.exitGuestMode()
                            }
                        )
                    } else {
                        CreatorStudioScreen(viewModel = viewModel)
                    }
                }
                Screen.AdminDashboard -> {
                    if (isGuestMode) {
                        GuestRestrictedPlaceholder(
                            featureTitle = "Admin Control Desk",
                            featureDescription = "Administrative access requires authorized super-admin credentials.",
                            onSignInClick = {
                                loginViewModel.exitGuestMode()
                                viewModel.exitGuestMode()
                            }
                        )
                    } else {
                        AdminDashboardScreen(viewModel = viewModel)
                    }
                }
            }
        }
    }

    // In-App Notification Dialog (e.g. Monetization Approved)
    inAppNotification?.let { notifText ->
        AlertDialog(
            onDismissRequest = { viewModel.clearInAppNotification() },
            title = {
                Text(
                    text = "🎉 Creator Notification",
                    fontWeight = FontWeight.Black,
                    fontSize = 16.sp
                )
            },
            text = {
                Text(
                    text = notifText,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.clearInAppNotification()
                        viewModel.navigateTo(Screen.CreatorStudio)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = LovraPrimary)
                ) {
                    Text("Go to Creator Studio", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.clearInAppNotification() }) {
                    Text("Dismiss")
                }
            }
        )
    }
}
