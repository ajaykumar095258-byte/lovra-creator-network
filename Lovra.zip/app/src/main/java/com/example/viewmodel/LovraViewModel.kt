package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.*
import com.example.repository.LovraDataRepository
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed class Screen(val route: String) {
    object Home : Screen("home")
    object Discover : Screen("discover")
    object Create : Screen("create")
    object Messages : Screen("messages")
    object Profile : Screen("profile")
    object StoryDetail : Screen("story_detail")
    object MonetizationApply : Screen("monetization_apply")
    object CreatorStudio : Screen("creator_studio")
    object AdminDashboard : Screen("admin_dashboard")
}

data class PlayerState(
    val story: StoryItem? = null,
    val currentEpisode: StoryEpisode? = null,
    val isPlaying: Boolean = false,
    val currentPositionSeconds: Int = 0,
    val totalDurationSeconds: Int = 300,
    val playbackSpeed: Float = 1.0f
)

class LovraViewModel(
    application: Application
) : AndroidViewModel(application) {

    val repository = LovraDataRepository(application)

    // Navigation Stack
    private val _currentScreen = MutableStateFlow<Screen>(Screen.Home)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val screenStack = mutableListOf<Screen>(Screen.Home)

    // Selected Story for detail view
    private val _selectedStory = MutableStateFlow<StoryItem?>(null)
    val selectedStory: StateFlow<StoryItem?> = _selectedStory.asStateFlow()

    // Global Player state
    private val _playerState = MutableStateFlow(PlayerState())
    val playerState: StateFlow<PlayerState> = _playerState.asStateFlow()

    // Search query & category filter
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategoryFilter = MutableStateFlow("All")
    val selectedCategoryFilter: StateFlow<String> = _selectedCategoryFilter.asStateFlow()

    private val _selectedFormatFilter = MutableStateFlow<ContentFormat?>(null)
    val selectedFormatFilter: StateFlow<ContentFormat?> = _selectedFormatFilter.asStateFlow()

    // UI Feedback Banner
    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    // Repository flows
    val currentUser = repository.currentUser
    val stories = repository.stories
    val episodes = repository.episodes
    val comments = repository.comments
    val followingSet = repository.followingSet
    val likedStoryIds = repository.likedStoryIds
    val savedStoryIds = repository.savedStoryIds
    val monetizationApplications = repository.monetizationApplications
    val adminMonetizationConfig = repository.adminMonetizationConfig
    val creatorEarnings = repository.creatorEarnings
    val withdrawals = repository.withdrawals
    val reports = repository.reports
    val messages = repository.messages
    val groups = repository.groups
    val auditLogs = repository.auditLogs
    val inAppNotification = repository.inAppNotification

    // Guest Mode flag
    private val _isGuestMode = MutableStateFlow(false)
    val isGuestMode: StateFlow<Boolean> = _isGuestMode.asStateFlow()

    init {
        // Automatically check if a genuine session exists on startup (Rule 2)
        val initialUser = Firebase.auth.currentUser
        if (initialUser != null) {
            repository.attachAuthSession(initialUser)
        }
    }

    fun onAuthSessionChanged(user: FirebaseUser?) {
        if (user != null) {
            _isGuestMode.value = false
            repository.attachAuthSession(user)
        } else if (!_isGuestMode.value) {
            repository.clearSession()
        }
    }

    fun enterGuestMode() {
        _isGuestMode.value = true
        repository.attachGuestSession()
        _currentScreen.value = Screen.Home
        screenStack.clear()
        screenStack.add(Screen.Home)
    }

    fun exitGuestMode() {
        _isGuestMode.value = false
        repository.clearSession()
    }

    fun onSignOut() {
        _isGuestMode.value = false
        repository.clearSession()
        _currentScreen.value = Screen.Home
        screenStack.clear()
        screenStack.add(Screen.Home)
        _selectedStory.value = null
        _playerState.value = PlayerState()
    }

    fun navigateTo(screen: Screen) {
        if (_currentScreen.value != screen) {
            screenStack.add(screen)
            _currentScreen.value = screen
        }
    }

    fun navigateBack(): Boolean {
        if (screenStack.size > 1) {
            screenStack.removeAt(screenStack.lastIndex)
            _currentScreen.value = screenStack.last()
            return true
        }
        return false
    }

    fun openStoryDetail(story: StoryItem) {
        _selectedStory.value = story
        val storyEpisodes = repository.episodes.value[story.id] ?: emptyList()
        val firstEp = storyEpisodes.firstOrNull()

        _playerState.value = PlayerState(
            story = story,
            currentEpisode = firstEp,
            isPlaying = true,
            currentPositionSeconds = 0,
            totalDurationSeconds = firstEp?.durationSeconds ?: story.durationSeconds
        )

        repository.recordPlaybackView(story.id, 35, story.durationSeconds)
        navigateTo(Screen.StoryDetail)
    }

    fun openStoryById(storyId: String): Boolean {
        val target = repository.stories.value.find { it.id == storyId }
        return if (target != null) {
            openStoryDetail(target)
            true
        } else {
            false
        }
    }

    fun handleDeepLink(uriString: String?) {
        if (uriString.isNullOrBlank()) return
        val uri = android.net.Uri.parse(uriString)
        val path = uri.path ?: return

        when {
            path.startsWith("/story/") -> {
                val storyId = path.removePrefix("/story/").trim('/')
                if (storyId.isNotEmpty()) {
                    val opened = openStoryById(storyId)
                    if (!opened) {
                        navigateTo(Screen.Discover)
                        showToast("Story loading...")
                    }
                }
            }
            path.startsWith("/creator/") || path == "/creators" -> {
                navigateTo(Screen.Discover)
            }
            path == "/discover" || path == "/audio" || path == "/drama" || path == "/anime" -> {
                navigateTo(Screen.Discover)
            }
            path == "/" -> {
                navigateTo(Screen.Home)
            }
        }
    }

    fun togglePlayerPlayback() {
        val curr = _playerState.value
        _playerState.value = curr.copy(isPlaying = !curr.isPlaying)
    }

    fun seekPlayer(seconds: Int) {
        val curr = _playerState.value
        val clamped = seconds.coerceIn(0, curr.totalDurationSeconds)
        _playerState.value = curr.copy(currentPositionSeconds = clamped)
        curr.story?.let { story ->
            repository.recordPlaybackView(story.id, clamped, curr.totalDurationSeconds)
        }
    }

    fun selectEpisode(episode: StoryEpisode) {
        val curr = _playerState.value
        _playerState.value = curr.copy(
            currentEpisode = episode,
            currentPositionSeconds = 0,
            totalDurationSeconds = episode.durationSeconds,
            isPlaying = true
        )
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setCategoryFilter(category: String) {
        _selectedCategoryFilter.value = category
    }

    fun setFormatFilter(format: ContentFormat?) {
        _selectedFormatFilter.value = format
    }

    fun toggleLike(storyId: String) {
        if (_isGuestMode.value) {
            showToast("Guest Mode: Sign in with Google to like stories.")
            return
        }
        repository.toggleLike(storyId)
    }

    fun toggleSave(storyId: String) {
        if (_isGuestMode.value) {
            showToast("Guest Mode: Sign in with Google to bookmark stories.")
            return
        }
        repository.toggleSave(storyId)
    }

    fun toggleFollow(creatorId: String) {
        if (_isGuestMode.value) {
            showToast("Guest Mode: Sign in with Google to follow creators.")
            return
        }
        repository.toggleFollow(creatorId)
    }

    fun addComment(storyId: String, text: String) {
        if (_isGuestMode.value) {
            showToast("Guest Mode: Sign in with Google to post comments.")
            return
        }
        if (repository.addComment(storyId, text)) {
            showToast("Comment posted!")
        }
    }

    fun publishStory(
        title: String,
        description: String,
        format: ContentFormat,
        category: String,
        language: String,
        tags: List<String>,
        epTitle: String,
        epTranscript: String,
        onSuccess: () -> Unit
    ) {
        if (_isGuestMode.value) {
            showToast("Guest Mode: Sign in with Google to publish content.")
            return
        }
        viewModelScope.launch {
            val result = repository.publishStory(
                title, description, format, category, language, tags, epTitle, epTranscript
            )
            result.onSuccess {
                showToast("Content published to LOVRA network!")
                onSuccess()
            }.onFailure {
                showToast("Error: ${it.message}")
            }
        }
    }

    // ==========================================
    // NEW PRODUCTION CREATOR MONETIZATION METHODS
    // ==========================================

    fun submitMonetizationApplication(
        paymentReference: String,
        paymentDate: String,
        paymentTime: String,
        paymentProof: String,
        onSuccess: () -> Unit
    ) {
        if (_isGuestMode.value) {
            showToast("Guest Mode: Sign in with Google to apply for monetization.")
            return
        }
        viewModelScope.launch {
            val res = repository.submitMonetizationApplication(
                paymentReference = paymentReference,
                paymentDate = paymentDate,
                paymentTime = paymentTime,
                paymentProof = paymentProof
            )
            res.onSuccess {
                showToast("Payment details submitted! Verification pending.")
                onSuccess()
            }.onFailure {
                showToast(it.message ?: "Application failed")
            }
        }
    }

    fun reviewMonetizationApplication(
        applicationId: String,
        approve: Boolean,
        rejectionReason: String,
        adminId: String = "ADMIN"
    ) {
        if (_isGuestMode.value) {
            showToast("Admin access requires authorized sign-in.")
            return
        }
        viewModelScope.launch {
            val res = repository.reviewMonetizationApplication(applicationId, approve, rejectionReason, adminId)
            res.onSuccess {
                showToast(if (approve) "Monetization Approved!" else "Monetization Application Rejected.")
            }.onFailure {
                showToast(it.message ?: "Action failed")
            }
        }
    }

    fun updateAdminMonetizationConfig(config: AdminMonetizationConfig) {
        repository.updateAdminMonetizationConfig(config)
        showToast("Monetization bot configuration saved.")
    }

    fun clearInAppNotification() {
        repository.clearInAppNotification()
    }

    fun submitWithdrawal(amount: Double, upiId: String, onSuccess: () -> Unit) {
        if (_isGuestMode.value) {
            showToast("Guest Mode: Sign in with Google to request withdrawals.")
            return
        }
        viewModelScope.launch {
            val res = repository.submitWithdrawal(amount, upiId)
            res.onSuccess {
                showToast("Withdrawal requested! Processing via Telegram finance desk.")
                onSuccess()
            }.onFailure {
                showToast(it.message ?: "Failed to request withdrawal")
            }
        }
    }

    fun submitReport(targetType: String, targetId: String, targetTitle: String, reason: String, details: String) {
        viewModelScope.launch {
            repository.submitReport(targetType, targetId, targetTitle, reason, details)
            showToast("Report submitted to Moderation & Telegram Alert sent.")
        }
    }

    fun sendMessage(conversationId: String, text: String) {
        if (_isGuestMode.value) {
            showToast("Guest Mode: Sign in with Google to chat.")
            return
        }
        if (repository.sendChatMessage(conversationId, text)) {
            showToast("Message sent.")
        }
    }

    fun updateProfile(displayName: String, bio: String, channelName: String, channelDesc: String) {
        if (_isGuestMode.value) {
            showToast("Guest Mode: Sign in with Google to update profile.")
            return
        }
        repository.updateProfile(displayName, bio, channelName, channelDesc)
        showToast("Profile & Channel updated.")
    }

    fun showToast(msg: String) {
        _toastMessage.value = msg
    }

    fun clearToast() {
        _toastMessage.value = null
    }
}
