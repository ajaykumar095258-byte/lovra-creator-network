package com.example.viewmodel

import android.content.Context
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.auth.authStateFlow
import com.example.auth.performGoogleSignIn
import com.example.auth.performSignOut
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn

sealed interface AuthState {
    object Initializing : AuthState
    data class Authenticated(val user: FirebaseUser) : AuthState
    object Guest : AuthState
    object Unauthenticated : AuthState
}

class LoginViewModel : ViewModel() {

    private val auth = Firebase.auth

    val authUser: StateFlow<FirebaseUser?> = auth.authStateFlow()
        .stateIn(viewModelScope, SharingStarted.Eagerly, auth.currentUser)

    private val _isGuestMode = MutableStateFlow(false)
    val isGuestMode: StateFlow<Boolean> = _isGuestMode.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    fun signInWithGoogle(
        context: Context,
        credentialManager: CredentialManager,
        onSuccess: (FirebaseUser) -> Unit = {}
    ) {
        _isLoading.value = true
        _errorMessage.value = null
        performGoogleSignIn(
            context = context,
            credentialManager = credentialManager,
            onAuthSuccess = { user ->
                _isLoading.value = false
                _isGuestMode.value = false
                onSuccess(user)
            },
            onAuthError = { err ->
                _isLoading.value = false
                _errorMessage.value = err
            },
            scope = viewModelScope,
            onAuthCancelled = {
                _isLoading.value = false
            }
        )
    }

    /**
     * Continue as Guest:
     * Bypasses account creation and grants read-only access to discover and watch content,
     * while restricting actions like posting comments, uploading media, and starting monetized channels.
     */
    fun continueAsGuest(onGuestConfirmed: () -> Unit = {}) {
        _isGuestMode.value = true
        _errorMessage.value = null
        onGuestConfirmed()
    }

    fun exitGuestMode() {
        _isGuestMode.value = false
    }

    fun signOut(context: Context, credentialManager: CredentialManager, onComplete: () -> Unit = {}) {
        _isGuestMode.value = false
        performSignOut(
            context = context,
            credentialManager = credentialManager,
            onSignOutComplete = {
                onComplete()
            },
            scope = viewModelScope
        )
    }

    fun clearError() {
        _errorMessage.value = null
    }
}
