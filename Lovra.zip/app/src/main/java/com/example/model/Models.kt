package com.example.model

enum class ContentFormat(val label: String, val iconName: String) {
    VIDEO("Video", "video"),
    SHORTS("Shorts", "shorts"),
    AUDIO("Audio", "audio"),
    AUDIO_VISUAL("Audio + Visual", "visual"),
    DRAMA("Drama", "drama"),
    ANIME("Anime", "anime")
}

enum class ModerationStatus {
    PROCESSING,
    UNDER_REVIEW,
    APPROVED,
    PUBLISHED,
    REJECTED,
    REMOVED,
    APPEALED
}

enum class CreatorMonetizationStatus {
    DISABLED,
    PENDING,
    ACTIVE,
    SUSPENDED
}

enum class MonetizationApplicationStatus {
    PENDING,
    APPROVED,
    REJECTED
}

enum class AdminRole {
    SUPER_ADMIN,
    MODERATOR,
    FINANCE_ADMIN,
    SUPPORT_ADMIN
}

data class UserProfile(
    val id: String,
    val username: String,
    val displayName: String,
    val email: String,
    val bio: String,
    val avatarUrl: String = "",
    val coverUrl: String = "",
    val isCreator: Boolean = false,
    val channelName: String = "",
    val channelDescription: String = "",
    val followersCount: Int = 0,
    val followingCount: Int = 0,
    val isVerified: Boolean = false,
    val creatorMonetizationEnabled: Boolean = false,
    val monetizationStatus: CreatorMonetizationStatus = CreatorMonetizationStatus.DISABLED,
    val paymentStatus: String = "UNPAID", // UNPAID, PENDING, VERIFIED
    val subscriptionExpiryDate: Long = 0L,
    val referralCode: String = "",
    val isGuest: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

data class StoryItem(
    val id: String,
    val creatorId: String,
    val creatorUsername: String,
    val creatorDisplayName: String,
    val channelName: String,
    val title: String,
    val description: String,
    val format: ContentFormat,
    val category: String,
    val language: String,
    val tags: List<String>,
    val durationSeconds: Int,
    val totalEpisodes: Int = 1,
    val viewsRaw: Long = 0L,
    val viewsQualified: Long = 0L,
    val likesCount: Int = 0,
    val commentsCount: Int = 0,
    val sharesCount: Int = 0,
    val savesCount: Int = 0,
    val moderationStatus: ModerationStatus = ModerationStatus.APPROVED,
    val createdAt: Long = System.currentTimeMillis(),
    val isFeatured: Boolean = false,
    val rightsConfirmed: Boolean = true
)

data class StoryEpisode(
    val id: String,
    val storyId: String,
    val seasonNumber: Int = 1,
    val episodeNumber: Int,
    val title: String,
    val description: String,
    val durationSeconds: Int,
    val transcript: String = "",
    val visualPromptOrNotes: String = ""
)

data class CommentItem(
    val id: String,
    val storyId: String,
    val userId: String,
    val username: String,
    val displayName: String,
    val text: String,
    val createdAt: Long = System.currentTimeMillis(),
    val likesCount: Int = 0
)

data class ChatMessage(
    val id: String,
    val conversationId: String,
    val senderId: String,
    val senderName: String,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false,
    val isFromAdmin: Boolean = false
)

data class GroupConversation(
    val id: String,
    val name: String,
    val description: String,
    val creatorId: String,
    val memberCount: Int = 1,
    val lastMessage: String = "",
    val lastMessageTime: Long = System.currentTimeMillis()
)

data class MonetizationApplication(
    val id: String = "",
    val creatorId: String = "",
    val username: String = "",
    val creatorName: String = "",
    val channelName: String = "",
    val amount: Int = 599,
    val currency: String = "INR",
    val paymentReference: String = "",
    val paymentDate: String = "",
    val paymentTime: String = "",
    val paymentProof: String = "",
    val status: MonetizationApplicationStatus = MonetizationApplicationStatus.PENDING,
    val rejectionReason: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val reviewedAt: Long? = null,
    val reviewedBy: String? = null
)

data class AdminMonetizationConfig(
    val activationFeeInr: Int = 599,
    val botUsername: String = "LovraCreatorBot",
    val botUrl: String = "https://t.me/LovraCreatorBot",
    val paymentInstructions: String = "Send ₹599 to LOVRA Official Banking/UPI: lovra.official@icici (IFSC: ICIC0001234). Include your LOVRA User ID in transaction remark."
)

data class CreatorEarnings(
    val creatorId: String,
    val estimatedEarnings: Double = 0.0,
    val pendingEarnings: Double = 0.0,
    val finalizedEarnings: Double = 0.0,
    val availableBalance: Double = 0.0,
    val paidAmount: Double = 0.0,
    val qualifiedViews: Long = 0L,
    val watchTimeMinutes: Long = 0L,
    val lastCalculatedAt: Long = System.currentTimeMillis()
)

data class WithdrawalRequest(
    val id: String,
    val creatorId: String,
    val username: String,
    val amount: Double,
    val upiIdOrBank: String,
    val status: String = "PENDING_REVIEW",
    val requestedAt: Long = System.currentTimeMillis(),
    val transactionRef: String = ""
)

data class ContentReport(
    val id: String,
    val reporterId: String,
    val reporterName: String,
    val targetType: String, // STORY, USER, COMMENT, COPYRIGHT
    val targetId: String,
    val targetTitle: String,
    val reason: String,
    val evidenceDetails: String,
    val status: String = "PENDING_REVIEW",
    val createdAt: Long = System.currentTimeMillis()
)

data class AuditLogEntry(
    val id: String,
    val actor: String,
    val action: String,
    val resource: String,
    val details: String,
    val timestamp: Long = System.currentTimeMillis()
)
