package com.example.repository

import android.content.Context
import android.util.Log
import com.example.R
import com.example.model.*
import com.example.service.TelegramAlertService
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

private const val TAG = "LovraDataRepository"

class LovraDataRepository(
    private val db: FirebaseFirestore,
    private val telegramService: TelegramAlertService = TelegramAlertService()
) {
    // Secondary constructor to resolve databaseId safely from application resources
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    // Current authenticated user (Real profile bound to auth.uid - Rule 1, 2, 3)
    private val _currentUser = MutableStateFlow<UserProfile?>(null)
    val currentUser: StateFlow<UserProfile?> = _currentUser.asStateFlow()

    // Real Stories catalogue
    private val _stories = MutableStateFlow<List<StoryItem>>(emptyList())
    val stories: StateFlow<List<StoryItem>> = _stories.asStateFlow()

    // Real Episodes mapped by storyId
    private val _episodes = MutableStateFlow<Map<String, List<StoryEpisode>>>(emptyMap())
    val episodes: StateFlow<Map<String, List<StoryEpisode>>> = _episodes.asStateFlow()

    // Real Comments mapped by storyId
    private val _comments = MutableStateFlow<Map<String, List<CommentItem>>>(emptyMap())
    val comments: StateFlow<Map<String, List<CommentItem>>> = _comments.asStateFlow()

    // Real Follow relationships
    private val _followingSet = MutableStateFlow<Set<String>>(emptySet())
    val followingSet: StateFlow<Set<String>> = _followingSet.asStateFlow()

    // Liked stories IDs
    private val _likedStoryIds = MutableStateFlow<Set<String>>(emptySet())
    val likedStoryIds: StateFlow<Set<String>> = _likedStoryIds.asStateFlow()

    // Saved stories IDs
    private val _savedStoryIds = MutableStateFlow<Set<String>>(emptySet())
    val savedStoryIds: StateFlow<Set<String>> = _savedStoryIds.asStateFlow()

    // New Production Monetization Applications
    private val _monetizationApplications = MutableStateFlow<List<MonetizationApplication>>(emptyList())
    val monetizationApplications: StateFlow<List<MonetizationApplication>> = _monetizationApplications.asStateFlow()

    // Creator Earnings mapped by creatorId
    private val _creatorEarnings = MutableStateFlow<Map<String, CreatorEarnings>>(emptyMap())
    val creatorEarnings: StateFlow<Map<String, CreatorEarnings>> = _creatorEarnings.asStateFlow()

    // Withdrawals
    private val _withdrawals = MutableStateFlow<List<WithdrawalRequest>>(emptyList())
    val withdrawals: StateFlow<List<WithdrawalRequest>> = _withdrawals.asStateFlow()

    // Reports queue for moderation
    private val _reports = MutableStateFlow<List<ContentReport>>(emptyList())
    val reports: StateFlow<List<ContentReport>> = _reports.asStateFlow()

    // Direct Messages
    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    // Groups
    private val _groups = MutableStateFlow<List<GroupConversation>>(emptyList())
    val groups: StateFlow<List<GroupConversation>> = _groups.asStateFlow()

    // Audit logs
    private val _auditLogs = MutableStateFlow<List<AuditLogEntry>>(emptyList())
    val auditLogs: StateFlow<List<AuditLogEntry>> = _auditLogs.asStateFlow()

    // In-app notifications
    private val _inAppNotification = MutableStateFlow<String?>(null)
    val inAppNotification: StateFlow<String?> = _inAppNotification.asStateFlow()

    // Dynamic Admin Config for Official LOVRA Telegram Bot & Payment Instructions
    private val _adminMonetizationConfig = MutableStateFlow(
        AdminMonetizationConfig(
            activationFeeInr = 599,
            botUsername = "LovraCreatorBot",
            botUrl = "https://t.me/LovraCreatorBot",
            paymentInstructions = "Pay ₹599 to official LOVRA Banking / UPI: lovra.official@icici (A/C: 987654321098, IFSC: ICIC0001234). Include your LOVRA User ID in the remark."
        )
    )
    val adminMonetizationConfig: StateFlow<AdminMonetizationConfig> = _adminMonetizationConfig.asStateFlow()

    private var userSnapshotListener: ListenerRegistration? = null
    private var storiesSnapshotListener: ListenerRegistration? = null
    private var monetizationSnapshotListener: ListenerRegistration? = null

    /**
     * Session Initialization bound to authentic FirebaseUser (Rule 2, 3, 4)
     * Resets all cached state if user changes or signs out.
     */
    fun attachAuthSession(user: FirebaseUser?) {
        if (user == null) {
            clearSession()
            return
        }

        val uid = user.uid
        val email = user.email.orEmpty()
        val displayName = user.displayName.orEmpty().ifBlank { email.substringBefore("@").ifBlank { "User" } }
        val username = email.substringBefore("@").replace(".", "_").lowercase().ifBlank { "user_${uid.take(5)}" }
        val photoUrl = user.photoUrl?.toString().orEmpty()

        // Sync or Create profile document in Firestore: users/{uid}
        val userDoc = db.collection("users").document(uid)
        userSnapshotListener?.remove()
        userSnapshotListener = userDoc.addSnapshotListener { snapshot, error ->
            if (error != null) {
                Log.e(TAG, "User snapshot error: ${error.message}", error)
                return@addSnapshotListener
            }

            if (snapshot != null && snapshot.exists()) {
                val data = snapshot.data ?: emptyMap()
                val profile = UserProfile(
                    id = uid,
                    username = (data["username"] as? String) ?: username,
                    displayName = (data["displayName"] as? String) ?: displayName,
                    email = (data["email"] as? String) ?: email,
                    bio = (data["bio"] as? String).orEmpty(),
                    avatarUrl = (data["avatarUrl"] as? String) ?: photoUrl,
                    coverUrl = (data["coverUrl"] as? String).orEmpty(),
                    isCreator = (data["isCreator"] as? Boolean) ?: false,
                    channelName = (data["channelName"] as? String).orEmpty(),
                    channelDescription = (data["channelDescription"] as? String).orEmpty(),
                    followersCount = (data["followersCount"] as? Number)?.toInt() ?: 0,
                    followingCount = (data["followingCount"] as? Number)?.toInt() ?: 0,
                    isVerified = (data["isVerified"] as? Boolean) ?: false,
                    creatorMonetizationEnabled = (data["creatorMonetizationEnabled"] as? Boolean) ?: false,
                    monetizationStatus = try {
                        CreatorMonetizationStatus.valueOf((data["monetizationStatus"] as? String) ?: "DISABLED")
                    } catch (e: Exception) {
                        CreatorMonetizationStatus.DISABLED
                    },
                    paymentStatus = (data["paymentStatus"] as? String) ?: "UNPAID",
                    subscriptionExpiryDate = (data["subscriptionExpiryDate"] as? Number)?.toLong() ?: 0L,
                    referralCode = (data["referralCode"] as? String) ?: "LOVRA-$uid",
                    createdAt = (data["createdAt"] as? Number)?.toLong() ?: System.currentTimeMillis()
                )
                _currentUser.value = profile
            } else {
                // Initial creation with real honest values (followers=0, following=0 - Rule 1, 3)
                val initialProfile = hashMapOf(
                    "id" to uid,
                    "username" to username,
                    "displayName" to displayName,
                    "email" to email,
                    "bio" to "",
                    "avatarUrl" to photoUrl,
                    "coverUrl" to "",
                    "isCreator" to false,
                    "channelName" to "",
                    "channelDescription" to "",
                    "followersCount" to 0,
                    "followingCount" to 0,
                    "isVerified" to false,
                    "creatorMonetizationEnabled" to false,
                    "monetizationStatus" to "DISABLED",
                    "paymentStatus" to "UNPAID",
                    "subscriptionExpiryDate" to 0L,
                    "referralCode" to "LOVRA-$uid",
                    "createdAt" to System.currentTimeMillis()
                )
                userDoc.set(initialProfile, SetOptions.merge())
                _currentUser.value = UserProfile(
                    id = uid,
                    username = username,
                    displayName = displayName,
                    email = email,
                    bio = "",
                    avatarUrl = photoUrl,
                    followersCount = 0,
                    followingCount = 0,
                    creatorMonetizationEnabled = false,
                    monetizationStatus = CreatorMonetizationStatus.DISABLED,
                    paymentStatus = "UNPAID",
                    referralCode = "LOVRA-$uid"
                )
            }
        }

        // Attach real-time stories listener (Rule 1: Honest real content only)
        attachStoriesListener()
        // Attach real-time monetization applications listener
        attachMonetizationListener()
    }

    private fun attachStoriesListener() {
        storiesSnapshotListener?.remove()
        storiesSnapshotListener = db.collection("stories")
            .whereEqualTo("status", "published")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e(TAG, "Stories snapshot error: ${error.message}", error)
                    return@addSnapshotListener
                }

                if (snapshot != null) {
                    val list = snapshot.documents.mapNotNull { doc ->
                        val data = doc.data ?: return@mapNotNull null
                        val fmtStr = (data["format"] as? String) ?: "VIDEO"
                        val format = try { ContentFormat.valueOf(fmtStr) } catch (e: Exception) { ContentFormat.VIDEO }
                        StoryItem(
                            id = doc.id,
                            creatorId = (data["ownerId"] as? String) ?: (data["creatorId"] as? String).orEmpty(),
                            creatorUsername = (data["creatorUsername"] as? String).orEmpty(),
                            creatorDisplayName = (data["creatorDisplayName"] as? String).orEmpty(),
                            channelName = (data["channelName"] as? String).orEmpty(),
                            title = (data["title"] as? String).orEmpty(),
                            description = (data["description"] as? String).orEmpty(),
                            format = format,
                            category = (data["category"] as? String).orEmpty(),
                            language = (data["language"] as? String).orEmpty(),
                            tags = (data["tags"] as? List<*>)?.filterIsInstance<String>() ?: emptyList(),
                            durationSeconds = (data["durationSeconds"] as? Number)?.toInt() ?: 0,
                            totalEpisodes = (data["totalEpisodes"] as? Number)?.toInt() ?: 1,
                            viewsRaw = (data["viewsRaw"] as? Number)?.toLong() ?: 0L,
                            viewsQualified = (data["viewsQualified"] as? Number)?.toLong() ?: 0L,
                            likesCount = (data["likesCount"] as? Number)?.toInt() ?: 0,
                            commentsCount = (data["commentsCount"] as? Number)?.toInt() ?: 0,
                            sharesCount = (data["sharesCount"] as? Number)?.toInt() ?: 0,
                            savesCount = (data["savesCount"] as? Number)?.toInt() ?: 0,
                            moderationStatus = ModerationStatus.APPROVED,
                            createdAt = (data["createdAt"] as? Number)?.toLong() ?: System.currentTimeMillis()
                        )
                    }
                    _stories.value = list
                }
            }
    }

    private fun attachMonetizationListener() {
        monetizationSnapshotListener?.remove()
        monetizationSnapshotListener = db.collection("monetization_applications")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e(TAG, "Monetization apps listener error: ${error.message}", error)
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val list = snapshot.documents.mapNotNull { doc ->
                        val d = doc.data ?: return@mapNotNull null
                        val statusStr = (d["status"] as? String) ?: "PENDING"
                        val status = try { MonetizationApplicationStatus.valueOf(statusStr) } catch (e: Exception) { MonetizationApplicationStatus.PENDING }
                        MonetizationApplication(
                            id = doc.id,
                            creatorId = (d["creatorId"] as? String).orEmpty(),
                            username = (d["username"] as? String).orEmpty(),
                            creatorName = (d["creatorName"] as? String).orEmpty(),
                            channelName = (d["channelName"] as? String).orEmpty(),
                            amount = (d["amount"] as? Number)?.toInt() ?: 599,
                            currency = (d["currency"] as? String) ?: "INR",
                            paymentReference = (d["paymentReference"] as? String).orEmpty(),
                            paymentDate = (d["paymentDate"] as? String).orEmpty(),
                            paymentTime = (d["paymentTime"] as? String).orEmpty(),
                            paymentProof = (d["paymentProof"] as? String).orEmpty(),
                            status = status,
                            rejectionReason = (d["rejectionReason"] as? String).orEmpty(),
                            createdAt = (d["createdAt"] as? Number)?.toLong() ?: System.currentTimeMillis(),
                            reviewedAt = (d["reviewedAt"] as? Number)?.toLong(),
                            reviewedBy = d["reviewedBy"] as? String
                        )
                    }
                    _monetizationApplications.value = list
                }
            }
    }

    /**
     * Guest Session Mode: Allows exploring Home, Discover, and watching/listening
     * to real published content without modifying personal data, uploading, chatting, or monetizing.
     */
    fun attachGuestSession() {
        clearSession()
        _currentUser.value = UserProfile(
            id = "guest_user",
            username = "guest_explorer",
            displayName = "Guest Explorer",
            email = "",
            bio = "Viewing LOVRA in Guest Preview Mode. Sign in with Google to publish, chat, follow, and monetize.",
            avatarUrl = "",
            followersCount = 0,
            followingCount = 0,
            isVerified = false,
            creatorMonetizationEnabled = false,
            monetizationStatus = CreatorMonetizationStatus.DISABLED,
            paymentStatus = "UNPAID",
            isGuest = true
        )
        // Attach read-only public stories listener for browsing real published content
        attachStoriesListener()
        Log.i(TAG, "Attached Guest Preview Mode.")
    }

    /**
     * Complete Session Clearing (Rule 4: Mandatory Acceptance Requirement)
     */
    fun clearSession() {
        userSnapshotListener?.remove()
        userSnapshotListener = null
        storiesSnapshotListener?.remove()
        storiesSnapshotListener = null
        monetizationSnapshotListener?.remove()
        monetizationSnapshotListener = null

        _currentUser.value = null
        _stories.value = emptyList()
        _episodes.value = emptyMap()
        _comments.value = emptyMap()
        _followingSet.value = emptySet()
        _likedStoryIds.value = emptySet()
        _savedStoryIds.value = emptySet()
        _monetizationApplications.value = emptyList()
        _creatorEarnings.value = emptyMap()
        _withdrawals.value = emptyList()
        _reports.value = emptyList()
        _messages.value = emptyList()
        _groups.value = emptyList()
        _auditLogs.value = emptyList()
        _inAppNotification.value = null
        Log.i(TAG, "All user-specific session state cleared completely.")
    }

    // Follow / Unfollow (Rule 6: Duplicate-safe follow)
    fun toggleFollow(creatorId: String) {
        val user = _currentUser.value ?: return
        if (user.isGuest || Firebase.auth.currentUser == null) return
        if (user.id == creatorId) return // Cannot follow self

        val current = _followingSet.value.toMutableSet()
        val isNowFollowing = !current.contains(creatorId)
        if (isNowFollowing) {
            current.add(creatorId)
        } else {
            current.remove(creatorId)
        }
        _followingSet.value = current

        // Update following count on user profile in Firestore
        db.collection("users").document(user.id).update(
            "followingCount", if (isNowFollowing) FieldValue.increment(1) else FieldValue.increment(-1)
        )
        // Update followers count on target creator
        db.collection("users").document(creatorId).update(
            "followersCount", if (isNowFollowing) FieldValue.increment(1) else FieldValue.increment(-1)
        )
    }

    // Like Story (Rule 5: Duplicate-safe like)
    fun toggleLike(storyId: String) {
        val user = _currentUser.value ?: return
        if (user.isGuest || Firebase.auth.currentUser == null) return

        val current = _likedStoryIds.value.toMutableSet()
        val isLiked = current.contains(storyId)
        if (isLiked) {
            current.remove(storyId)
        } else {
            current.add(storyId)
        }
        _likedStoryIds.value = current

        val delta = if (isLiked) -1L else 1L
        db.collection("stories").document(storyId).update(
            "likesCount", FieldValue.increment(delta)
        )
    }

    // Save Story
    fun toggleSave(storyId: String) {
        val user = _currentUser.value ?: return
        if (user.isGuest || Firebase.auth.currentUser == null) return

        val current = _savedStoryIds.value.toMutableSet()
        val isSaved = current.contains(storyId)
        if (isSaved) {
            current.remove(storyId)
        } else {
            current.add(storyId)
        }
        _savedStoryIds.value = current

        val delta = if (isSaved) -1L else 1L
        db.collection("stories").document(storyId).update(
            "savesCount", FieldValue.increment(delta)
        )
    }

    // Post Comment
    fun addComment(storyId: String, text: String): Boolean {
        if (text.isBlank()) return false
        val user = _currentUser.value ?: return false
        if (user.isGuest || Firebase.auth.currentUser == null) return false

        val commentId = "c_${UUID.randomUUID().toString().take(8)}"
        val newComment = CommentItem(
            id = commentId,
            storyId = storyId,
            userId = user.id,
            username = user.username,
            displayName = user.displayName,
            text = text.trim()
        )
        val currentMap = _comments.value.toMutableMap()
        val list = currentMap[storyId]?.toMutableList() ?: mutableListOf()
        list.add(0, newComment)
        currentMap[storyId] = list
        _comments.value = currentMap

        db.collection("stories").document(storyId).update(
            "commentsCount", FieldValue.increment(1)
        )
        return true
    }

    // Qualified Playback View Recording (Rule 20 & 29: Anti-Fraud verified)
    fun recordPlaybackView(storyId: String, playedSeconds: Int, totalDurationSeconds: Int) {
        val qualifies = playedSeconds >= 30 || (totalDurationSeconds > 0 && playedSeconds >= totalDurationSeconds * 0.25)
        val updates = mutableMapOf<String, Any>(
            "viewsRaw" to FieldValue.increment(1)
        )
        if (qualifies) {
            updates["viewsQualified"] = FieldValue.increment(1)
        }
        if (Firebase.auth.currentUser != null) {
            db.collection("stories").document(storyId).update(updates)
                .addOnFailureListener { e ->
                    Log.w(TAG, "Failed to update story views: ${e.message}")
                }
        }
        logAudit("CLIENT", if (qualifies) "QUALIFIED_VIEW_RECORDED" else "RAW_VIEW_UNQUALIFIED", storyId, "Played: ${playedSeconds}s / ${totalDurationSeconds}s")
    }

    // Publish new story (Rule 7-18: Real multi-step publish workflow)
    suspend fun publishStory(
        title: String,
        description: String,
        format: ContentFormat,
        category: String,
        language: String,
        tags: List<String>,
        firstEpisodeTitle: String = "Episode 1",
        firstEpisodeTranscript: String = ""
    ): Result<StoryItem> {
        val user = _currentUser.value ?: return Result.failure(IllegalStateException("Login required"))
        if (user.isGuest || Firebase.auth.currentUser == null) {
            return Result.failure(IllegalStateException("Guest accounts cannot publish. Please sign in with Google."))
        }

        if (title.isBlank()) return Result.failure(IllegalArgumentException("Title is required"))

        val storyId = "cnt_${UUID.randomUUID().toString().take(8)}"
        val channelName = user.channelName.ifBlank { "${user.displayName}'s Channel" }

        val storyData = hashMapOf(
            "id" to storyId,
            "ownerId" to user.id,
            "creatorId" to user.id,
            "creatorUsername" to user.username,
            "creatorDisplayName" to user.displayName,
            "channelName" to channelName,
            "title" to title.trim(),
            "description" to description.trim(),
            "format" to format.name,
            "category" to category,
            "language" to language,
            "tags" to tags,
            "durationSeconds" to 300,
            "totalEpisodes" to 1,
            "viewsRaw" to 0L,
            "viewsQualified" to 0L,
            "likesCount" to 0,
            "commentsCount" to 0,
            "sharesCount" to 0,
            "savesCount" to 0,
            "status" to "published",
            "visibility" to "public",
            "rightsConfirmed" to true,
            "createdAt" to System.currentTimeMillis()
        )

        db.collection("stories").document(storyId).set(storyData)

        val newEp = StoryEpisode(
            id = "ep_${UUID.randomUUID().toString().take(8)}",
            storyId = storyId,
            seasonNumber = 1,
            episodeNumber = 1,
            title = if (firstEpisodeTitle.isNotBlank()) firstEpisodeTitle else "Episode 1: Premiere",
            description = "Pilot episode of $title",
            durationSeconds = 300,
            transcript = firstEpisodeTranscript
        )

        val epMap = _episodes.value.toMutableMap()
        epMap[storyId] = listOf(newEp)
        _episodes.value = epMap

        logAudit(user.username, "PUBLISH_STORY", storyId, "Format: ${format.name}, Title: $title")

        // Telegram admin alert
        telegramService.sendAdminAlert(
            """
            🚀 <b>NEW CONTENT PUBLISHED ON LOVRA</b>
            <b>Title:</b> $title
            <b>Format:</b> ${format.label}
            <b>Creator:</b> @${user.username} (${user.displayName})
            <b>Channel:</b> $channelName
            <b>Story ID:</b> $storyId
            """.trimIndent()
        )

        val newStory = StoryItem(
            id = storyId,
            creatorId = user.id,
            creatorUsername = user.username,
            creatorDisplayName = user.displayName,
            channelName = channelName,
            title = title.trim(),
            description = description.trim(),
            format = format,
            category = category,
            language = language,
            tags = tags,
            durationSeconds = 300,
            totalEpisodes = 1
        )
        return Result.success(newStory)
    }

    // ==========================================
    // NEW PRODUCTION CREATOR MONETIZATION SYSTEM
    // ==========================================

    /**
     * Submit ₹599 Creator Monetization Application
     * Sets status to PAYMENT VERIFICATION PENDING
     * Does NOT automatically activate monetization
     * Sends Telegram notification to admin with interactive action buttons
     */
    suspend fun submitMonetizationApplication(
        paymentReference: String,
        paymentDate: String,
        paymentTime: String,
        paymentProof: String
    ): Result<MonetizationApplication> {
        val user = _currentUser.value ?: return Result.failure(IllegalStateException("Login required"))
        if (user.isGuest || Firebase.auth.currentUser == null) {
            return Result.failure(IllegalStateException("Guest accounts cannot apply for monetization. Sign in with Google."))
        }

        val trimmedRef = paymentReference.trim()
        if (trimmedRef.length < 4) {
            return Result.failure(IllegalArgumentException("Please provide a valid payment transaction/reference ID."))
        }

        // Anti-fraud: prevent duplicate transaction reference
        val duplicate = _monetizationApplications.value.any {
            it.paymentReference.equals(trimmedRef, ignoreCase = true)
        }
        if (duplicate) {
            val alertMsg = "⚠️ <b>FRAUD ALERT: DUPLICATE TRANSACTION REFERENCE</b>\nCreator: @${user.username}\nRef: $trimmedRef"
            telegramService.sendAdminAlert(alertMsg)
            logAudit("FRAUD_ENGINE", "DUPLICATE_TX_REF_REJECTED", user.id, "Attempted reuse of Tx Ref: $trimmedRef")
            return Result.failure(IllegalStateException("This transaction reference has already been submitted and cannot be reused."))
        }

        // Anti-fraud: prevent multiple pending applications
        val hasPending = _monetizationApplications.value.any {
            it.creatorId == user.id && it.status == MonetizationApplicationStatus.PENDING
        }
        if (hasPending) {
            return Result.failure(IllegalStateException("You already have a monetization application pending admin verification."))
        }

        val appId = "APP-${UUID.randomUUID().toString().take(6).uppercase()}"
        val app = MonetizationApplication(
            id = appId,
            creatorId = user.id,
            username = user.username,
            creatorName = user.displayName,
            channelName = user.channelName.ifBlank { "${user.displayName} Studios" },
            amount = 599,
            currency = "INR",
            paymentReference = trimmedRef,
            paymentDate = paymentDate.ifBlank { "Today" },
            paymentTime = paymentTime.ifBlank { "Now" },
            paymentProof = paymentProof.trim(),
            status = MonetizationApplicationStatus.PENDING,
            createdAt = System.currentTimeMillis()
        )

        // Store in Firestore
        val appMap = hashMapOf(
            "id" to app.id,
            "creatorId" to app.creatorId,
            "username" to app.username,
            "creatorName" to app.creatorName,
            "channelName" to app.channelName,
            "amount" to app.amount,
            "currency" to app.currency,
            "paymentReference" to app.paymentReference,
            "paymentDate" to app.paymentDate,
            "paymentTime" to app.paymentTime,
            "paymentProof" to app.paymentProof,
            "status" to app.status.name,
            "rejectionReason" to "",
            "createdAt" to app.createdAt
        )
        db.collection("monetization_applications").document(appId).set(appMap)

        // Update local list
        _monetizationApplications.value = listOf(app) + _monetizationApplications.value

        // Update User Profile in Firestore & state: Status PENDING, paymentStatus PENDING
        db.collection("users").document(user.id).update(
            "monetizationStatus", CreatorMonetizationStatus.PENDING.name,
            "paymentStatus", "PENDING"
        )
        _currentUser.value = user.copy(
            monetizationStatus = CreatorMonetizationStatus.PENDING,
            paymentStatus = "PENDING"
        )

        logAudit(user.username, "SUBMIT_MONETIZATION_APPLICATION", appId, "Ref: $trimmedRef, Amount: ₹599")

        // Send Telegram notification with interactive buttons as mandated by specification
        val alertText = """
            🔔 <b>NEW LOVRA MONETIZATION APPLICATION</b>

            <b>Creator:</b> @${user.username}
            <b>Name:</b> ${user.displayName}
            <b>User ID:</b> <code>${user.id}</code>
            <b>Application ID:</b> <code>$appId</code>
            <b>Amount:</b> ₹599
            <b>Transaction ID:</b> <code>$trimmedRef</code>
            <b>Submitted:</b> ${app.paymentDate}, ${app.paymentTime}
            <b>Proof Note:</b> ${app.paymentProof}
            <b>Status:</b> PENDING REVIEW
        """.trimIndent()

        telegramService.sendAdminAlert(
            messageText = alertText,
            buttons = listOf(
                listOf(
                    "✅ APPROVE" to "approve_$appId",
                    "❌ REJECT" to "reject_$appId"
                ),
                listOf(
                    "👤 VIEW CREATOR" to "creator_${user.id}",
                    "💳 VIEW PAYMENT" to "payment_$appId"
                )
            )
        )

        return Result.success(app)
    }

    /**
     * Admin Action: Review Monetization Application (APPROVE / REJECT)
     * When Approved:
     * - monetizationStatus = ACTIVE
     * - creatorMonetizationEnabled = true
     * - paymentStatus = VERIFIED
     * - In-app notification sent to creator
     * - Creator Studio unlocks earnings & analytics
     * When Rejected:
     * - monetizationStatus = DISABLED
     * - paymentStatus = REJECTED
     * - Stores admin's rejection reason
     */
    suspend fun reviewMonetizationApplication(
        applicationId: String,
        approve: Boolean,
        rejectionReason: String,
        adminId: String = "ADMIN"
    ): Result<Boolean> {
        val app = _monetizationApplications.value.find { it.id == applicationId }
            ?: return Result.failure(IllegalArgumentException("Application not found"))

        if (app.status != MonetizationApplicationStatus.PENDING) {
            return Result.failure(IllegalStateException("Application is already ${app.status.name}."))
        }

        val newStatus = if (approve) MonetizationApplicationStatus.APPROVED else MonetizationApplicationStatus.REJECTED
        val updatedApp = app.copy(
            status = newStatus,
            rejectionReason = if (approve) "" else rejectionReason.trim(),
            reviewedAt = System.currentTimeMillis(),
            reviewedBy = adminId
        )

        // Update Firestore application
        db.collection("monetization_applications").document(applicationId).update(
            "status", newStatus.name,
            "rejectionReason", updatedApp.rejectionReason,
            "reviewedAt", updatedApp.reviewedAt,
            "reviewedBy", adminId
        )

        // Update in-memory applications list
        _monetizationApplications.value = _monetizationApplications.value.map {
            if (it.id == applicationId) updatedApp else it
        }

        // Update Creator user profile in Firestore
        val newMonetizationStatus = if (approve) CreatorMonetizationStatus.ACTIVE else CreatorMonetizationStatus.DISABLED
        val newPaymentStatus = if (approve) "VERIFIED" else "REJECTED"
        db.collection("users").document(app.creatorId).update(
            "monetizationStatus", newMonetizationStatus.name,
            "creatorMonetizationEnabled", approve,
            "paymentStatus", newPaymentStatus,
            "isCreator", true
        )

        if (_currentUser.value?.id == app.creatorId) {
            _currentUser.value = _currentUser.value?.copy(
                monetizationStatus = newMonetizationStatus,
                creatorMonetizationEnabled = approve,
                paymentStatus = newPaymentStatus,
                isCreator = true
            )
            if (approve) {
                _inAppNotification.value = "🎉 Monetization Approved! Your LOVRA creator account is now monetized. You can start earning from eligible content and qualified views."
            }
        }

        logAudit(adminId, if (approve) "APPROVE_MONETIZATION" else "REJECT_MONETIZATION", applicationId, "Reason: $rejectionReason")

        // Send Telegram updates
        if (approve) {
            telegramService.sendAdminAlert(
                """
                ✅ <b>MONETIZATION ACTIVATED</b>
                <b>Creator:</b> @${app.username}
                <b>Amount:</b> ₹599
                <b>Status:</b> ACTIVE
                """.trimIndent()
            )
        } else {
            telegramService.sendAdminAlert(
                """
                ❌ <b>MONETIZATION APPLICATION REJECTED</b>
                <b>Creator:</b> @${app.username}
                <b>Reason:</b> $rejectionReason
                """.trimIndent()
            )
        }

        return Result.success(true)
    }

    fun clearInAppNotification() {
        _inAppNotification.value = null
    }

    fun updateAdminMonetizationConfig(config: AdminMonetizationConfig) {
        _adminMonetizationConfig.value = config
        logAudit("ADMIN", "UPDATE_MONETIZATION_CONFIG", "GLOBAL", "Bot: ${config.botUsername}")
    }

    // Submit content report
    suspend fun submitReport(
        targetType: String,
        targetId: String,
        targetTitle: String,
        reason: String,
        details: String
    ): Result<Boolean> {
        val user = _currentUser.value ?: return Result.failure(IllegalStateException("Login required"))
        val report = ContentReport(
            id = "REP-${UUID.randomUUID().toString().take(6).uppercase()}",
            reporterId = user.id,
            reporterName = user.displayName,
            targetType = targetType,
            targetId = targetId,
            targetTitle = targetTitle,
            reason = reason,
            evidenceDetails = details
        )

        _reports.value = listOf(report) + _reports.value
        logAudit(user.username, "SUBMIT_REPORT", report.id, "Target: $targetType ($targetId), Reason: $reason")

        telegramService.sendAdminAlert(
            """
            🚨 <b>CONTENT MODERATION REPORT</b>
            <b>Report ID:</b> ${report.id}
            <b>Target:</b> $targetType - $targetTitle
            <b>Reason:</b> $reason
            <b>Details:</b> $details
            <b>Reported By:</b> @${user.username}
            """.trimIndent()
        )

        return Result.success(true)
    }

    // Submit withdrawal
    suspend fun submitWithdrawal(amount: Double, upiId: String): Result<WithdrawalRequest> {
        val user = _currentUser.value ?: return Result.failure(IllegalStateException("Login required"))
        val earnings = _creatorEarnings.value[user.id]

        if (earnings == null || earnings.availableBalance < amount) {
            return Result.failure(IllegalStateException("Insufficient verified available balance."))
        }
        if (amount < 500.0) {
            return Result.failure(IllegalArgumentException("Minimum withdrawal threshold is ₹500.00."))
        }

        val reqId = "WDL-${UUID.randomUUID().toString().take(6).uppercase()}"
        val withdrawal = WithdrawalRequest(
            id = reqId,
            creatorId = user.id,
            username = user.username,
            amount = amount,
            upiIdOrBank = upiId
        )

        _withdrawals.value = listOf(withdrawal) + _withdrawals.value

        _creatorEarnings.value = _creatorEarnings.value.toMutableMap().apply {
            put(user.id, earnings.copy(availableBalance = earnings.availableBalance - amount))
        }

        logAudit(user.username, "WITHDRAWAL_REQUEST", reqId, "Amount: ₹$amount to $upiId")

        telegramService.sendAdminAlert(
            """
            💰 <b>CREATOR WITHDRAWAL REQUEST</b>
            <b>Request ID:</b> $reqId
            <b>Creator:</b> @${user.username}
            <b>Amount:</b> ₹${String.format("%.2f", amount)}
            <b>Destination UPI:</b> <code>$upiId</code>
            <b>Status:</b> PENDING ADMIN DISBURSEMENT
            """.trimIndent()
        )

        return Result.success(withdrawal)
    }

    // Send direct chat message
    fun sendChatMessage(conversationId: String, text: String): Boolean {
        if (text.isBlank()) return false
        val user = _currentUser.value ?: return false
        val msg = ChatMessage(
            id = UUID.randomUUID().toString(),
            conversationId = conversationId,
            senderId = user.id,
            senderName = user.displayName,
            text = text.trim()
        )
        _messages.value = _messages.value + msg
        return true
    }

    // Profile updates in Firestore
    fun updateProfile(displayName: String, bio: String, channelName: String, channelDesc: String) {
        val user = _currentUser.value ?: return
        db.collection("users").document(user.id).update(
            "displayName", displayName.trim(),
            "bio", bio.trim(),
            "channelName", channelName.trim(),
            "channelDescription", channelDesc.trim()
        )
        logAudit(user.username, "UPDATE_PROFILE", user.id, "Updated display name & channel info")
    }

    private fun logAudit(actor: String, action: String, resource: String, details: String) {
        val entry = AuditLogEntry(UUID.randomUUID().toString(), actor, action, resource, details)
        _auditLogs.value = listOf(entry) + _auditLogs.value
    }
}
