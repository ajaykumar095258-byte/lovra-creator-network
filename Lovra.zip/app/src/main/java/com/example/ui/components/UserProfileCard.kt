package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.UserProfile
import com.example.ui.theme.*

/**
 * Premium, reusable User Profile Card component for LOVRA.
 * Features:
 * - Profile Picture with gradient fallback ring, initials or custom image
 * - Verified Creator Badge & Channel branding
 * - Creator Bio & category tags
 * - Real-time Follow / Following button state
 * - Clean follower count & interactive touch targets
 * - Supports both compact (list/feed) and expanded (header/detail) modes
 */
@Composable
fun UserProfileCard(
    user: UserProfile,
    isFollowing: Boolean,
    onFollowClick: () -> Unit,
    modifier: Modifier = Modifier,
    onProfileClick: (() -> Unit)? = null,
    showStats: Boolean = true,
    isCompact: Boolean = false
) {
    Surface(
        color = LovraSurfaceLight,
        shape = RoundedCornerShape(16.dp),
        shadowElevation = 1.dp,
        border = CardDefaults.outlinedCardBorder().copy(
            brush = androidx.compose.ui.graphics.SolidColor(LovraBorder)
        ),
        modifier = modifier
            .fillMaxWidth()
            .then(
                if (onProfileClick != null) {
                    Modifier.clickable { onProfileClick() }
                } else {
                    Modifier
                }
            )
            .testTag("user_profile_card_${user.id}")
    ) {
        if (isCompact) {
            // Horizontal compact layout (e.g. for feed creator byline or recommendations)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    UserProfileAvatar(
                        displayName = user.displayName,
                        size = 46.dp
                    )

                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = user.displayName.ifBlank { "Creator" },
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = LovraTextPrimary
                                ),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            if (user.isVerified) {
                                Icon(
                                    imageVector = Icons.Default.Verified,
                                    contentDescription = "Verified Creator",
                                    tint = LovraPrimary,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }

                        Text(
                            text = "@${user.username.ifBlank { "creator" }}",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = LovraTextSecondary
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )

                        if (user.bio.isNotBlank()) {
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = user.bio,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = LovraTextSecondary,
                                    fontSize = 11.sp
                                ),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.width(10.dp))

                FollowButton(
                    isFollowing = isFollowing,
                    onFollowClick = onFollowClick,
                    creatorId = user.id
                )
            }
        } else {
            // Full expanded layout featuring avatar, bio, stats, and follow button
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Large Avatar
                UserProfileAvatar(
                    displayName = user.displayName,
                    size = 72.dp
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Name & Verified Badge
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = user.displayName.ifBlank { "Creator" },
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = LovraTextPrimary
                        )
                    )
                    if (user.isVerified) {
                        Icon(
                            imageVector = Icons.Default.Verified,
                            contentDescription = "Verified Creator",
                            tint = LovraPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                // Handle & Channel Name
                Text(
                    text = if (user.channelName.isNotBlank()) {
                        "@${user.username} • ${user.channelName}"
                    } else {
                        "@${user.username}"
                    },
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = LovraPrimary,
                        fontWeight = FontWeight.SemiBold
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                // User Bio
                Text(
                    text = user.bio.ifBlank { "Storyteller & Creator on LOVRA." },
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = LovraTextSecondary,
                        lineHeight = 20.sp
                    ),
                    modifier = Modifier.padding(horizontal = 8.dp)
                )

                if (showStats) {
                    Spacer(modifier = Modifier.height(14.dp))
                    Divider(color = LovraBorder, thickness = 0.5.dp)
                    Spacer(modifier = Modifier.height(12.dp))

                    // Stats Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        ProfileStatItem(
                            value = "${user.followersCount}",
                            label = "Followers"
                        )
                        ProfileStatItem(
                            value = "${user.followingCount}",
                            label = "Following"
                        )
                        if (user.isCreator) {
                            ProfileStatItem(
                                value = "Creator",
                                label = "Tier"
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Follow Button (Full Width in expanded card)
                FollowButton(
                    isFollowing = isFollowing,
                    onFollowClick = onFollowClick,
                    creatorId = user.id,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

/**
 * Avatar with stylish gradient ring and initials
 */
@Composable
fun UserProfileAvatar(
    displayName: String,
    size: Dp = 56.dp,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .background(Brush.linearGradient(listOf(LovraPrimary, LovraSecondary)))
            .border(2.dp, Color.White, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        val initial = displayName.trim().take(1).uppercase().ifBlank { "L" }
        Text(
            text = initial,
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Black,
                color = Color.White,
                fontSize = (size.value * 0.42f).sp
            )
        )
    }
}

/**
 * Follow / Following Toggle Button
 */
@Composable
fun FollowButton(
    isFollowing: Boolean,
    onFollowClick: () -> Unit,
    creatorId: String,
    modifier: Modifier = Modifier
) {
    val buttonColor by animateColorAsState(
        targetValue = if (isFollowing) LovraSurfaceVariant else LovraPrimary,
        animationSpec = tween(durationMillis = 200),
        label = "follow_button_color"
    )

    Button(
        onClick = onFollowClick,
        colors = ButtonDefaults.buttonColors(containerColor = buttonColor),
        shape = RoundedCornerShape(20.dp),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
        modifier = modifier.testTag("follow_button_$creatorId")
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = if (isFollowing) Icons.Default.Check else Icons.Default.PersonAdd,
                contentDescription = null,
                tint = if (isFollowing) LovraTextPrimary else Color.White,
                modifier = Modifier.size(16.dp)
            )
            Text(
                text = if (isFollowing) "Following" else "Follow",
                color = if (isFollowing) LovraTextPrimary else Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
            )
        }
    }
}

@Composable
private fun ProfileStatItem(
    value: String,
    label: String
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = value,
            fontWeight = FontWeight.Bold,
            color = LovraTextPrimary,
            fontSize = 15.sp
        )
        Text(
            text = label,
            color = LovraTextSecondary,
            fontSize = 11.sp
        )
    }
}
