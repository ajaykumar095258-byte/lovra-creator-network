package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CreatorMonetizationStatus
import com.example.model.MonetizationApplicationStatus
import com.example.ui.theme.*
import com.example.viewmodel.LovraViewModel
import com.example.viewmodel.Screen
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun MonetizationApplyScreen(
    viewModel: LovraViewModel,
    modifier: Modifier = Modifier
) {
    val currentUser by viewModel.currentUser.collectAsState()
    val adminConfig by viewModel.adminMonetizationConfig.collectAsState()
    val applications by viewModel.monetizationApplications.collectAsState()
    val context = LocalContext.current

    val myApp = applications.firstOrNull { it.creatorId == currentUser?.id }

    var stepFourExpanded by remember { mutableStateOf(false) }
    var txReference by remember { mutableStateOf("") }
    var paymentDate by remember {
        mutableStateOf(SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date()))
    }
    var paymentTime by remember {
        mutableStateOf(SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date()))
    }
    var paymentProofNote by remember { mutableStateOf("") }
    var isSubmitting by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(LovraLightBg)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .padding(bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Navigation Header
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            IconButton(
                onClick = { viewModel.navigateBack() },
                modifier = Modifier.testTag("back_button_monetization")
            ) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Back",
                    tint = LovraTextPrimary
                )
            }
            Column {
                Text(
                    text = "Monetize Your Account",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Black,
                        letterSpacing = 0.5.sp,
                        color = LovraTextPrimary
                    )
                )
                Text(
                    text = "Turn your eligible LOVRA content into an earning opportunity.",
                    style = MaterialTheme.typography.bodySmall.copy(color = LovraTextSecondary, fontSize = 11.5.sp)
                )
            }
        }

        // ==========================================
        // STATE 1: ALREADY ACTIVE (MONETIZATION ACTIVE)
        // ==========================================
        if (currentUser?.creatorMonetizationEnabled == true || currentUser?.monetizationStatus == CreatorMonetizationStatus.ACTIVE) {
            Surface(
                color = LovraSuccess.copy(alpha = 0.08f),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(LovraSuccess)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(LovraSuccess),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color.White, modifier = Modifier.size(32.dp))
                    }
                    Text(
                        text = "MONETIZATION: ACTIVE ✅",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Black,
                            color = LovraSuccess
                        )
                    )
                    Text(
                        text = "🎉 Monetization Approved!\nYour LOVRA creator account is now monetized. You can start earning from eligible content and qualified views.",
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = LovraTextPrimary,
                            lineHeight = 20.sp
                        )
                    )
                    Button(
                        onClick = { viewModel.navigateTo(Screen.CreatorStudio) },
                        colors = ButtonDefaults.buttonColors(containerColor = LovraPrimary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("open_studio_monetized_button")
                    ) {
                        Text("Open Creator Studio & Analytics", fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }
            return@Column
        }

        // ==========================================
        // STATE 2: VERIFICATION PENDING
        // ==========================================
        if (myApp?.status == MonetizationApplicationStatus.PENDING || currentUser?.monetizationStatus == CreatorMonetizationStatus.PENDING) {
            Surface(
                color = LovraWarning.copy(alpha = 0.08f),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(LovraWarning)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.HourglassTop, contentDescription = null, tint = LovraWarning, modifier = Modifier.size(24.dp))
                        Text(
                            text = "PAYMENT VERIFICATION PENDING",
                            fontWeight = FontWeight.Black,
                            color = LovraWarning,
                            fontSize = 14.sp
                        )
                    }
                    Text(
                        text = "Your payment has been submitted successfully. LOVRA administration will independently verify your payment and review your monetization application.",
                        style = MaterialTheme.typography.bodyMedium.copy(color = LovraTextPrimary, lineHeight = 20.sp)
                    )
                    Divider(color = LovraDivider)
                    myApp?.let { app ->
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("Application ID: ${app.id}", fontSize = 11.sp, color = LovraTextSecondary)
                            Text("Transaction Ref: ${app.paymentReference}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = LovraTextPrimary)
                            Text("Amount: ₹${app.amount} INR", fontSize = 11.sp, color = LovraPrimary, fontWeight = FontWeight.Bold)
                            Text("Date / Time: ${app.paymentDate} at ${app.paymentTime}", fontSize = 11.sp, color = LovraTextSecondary)
                        }
                    }
                }
            }
            return@Column
        }

        // ==========================================
        // STATE 3: APPLICATION REJECTED (SHOW REASON)
        // ==========================================
        if (myApp?.status == MonetizationApplicationStatus.REJECTED) {
            Surface(
                color = LovraError.copy(alpha = 0.08f),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(LovraError)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.Cancel, contentDescription = null, tint = LovraError, modifier = Modifier.size(22.dp))
                        Text(
                            text = "Monetization Application Rejected",
                            fontWeight = FontWeight.Black,
                            color = LovraError,
                            fontSize = 14.sp
                        )
                    }
                    Text(
                        text = "Reason: ${myApp.rejectionReason.ifBlank { "Payment could not be verified by administration." }}",
                        style = MaterialTheme.typography.bodySmall.copy(color = LovraTextPrimary, fontWeight = FontWeight.SemiBold)
                    )
                    Text(
                        text = "You can re-verify your transaction details or re-apply below.",
                        style = MaterialTheme.typography.bodySmall.copy(color = LovraTextSecondary, fontSize = 11.sp)
                    )
                }
            }
        }

        // ==========================================
        // MAIN MONETIZATION OVERVIEW & BENEFITS
        // ==========================================
        Surface(
            color = LovraSurfaceLight,
            shape = RoundedCornerShape(16.dp),
            shadowElevation = 2.dp,
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(LovraBorder)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text(
                    text = "WHY MONETIZE?",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Black,
                        color = LovraPrimary,
                        letterSpacing = 1.sp
                    )
                )

                val benefits = listOf(
                    "Earn from eligible content & storytelling" to Icons.Default.MonetizationOn,
                    "Access Creator Earnings & verified ledger" to Icons.Default.AccountBalanceWallet,
                    "View qualified-view analytics & watch duration" to Icons.Default.Analytics,
                    "Track your monetization performance in real time" to Icons.Default.TrendingUp,
                    "Access creator payout & withdrawal features (Min ₹500)" to Icons.Default.Payments
                )

                benefits.forEach { (text, icon) ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(LovraPrimary.copy(alpha = 0.1f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(icon, contentDescription = null, tint = LovraPrimary, modifier = Modifier.size(18.dp))
                        }
                        Text(
                            text = text,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = LovraTextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium
                            )
                        )
                    }
                }
            }
        }

        // ==========================================
        // HOW IT WORKS: STEP-BY-STEP OFFICIAL PROCESS
        // ==========================================
        Text(
            text = "HOW TO APPLY",
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Black,
                color = LovraPrimary,
                letterSpacing = 1.sp
            )
        )

        // Step 1: Download Telegram
        Surface(
            color = LovraSurfaceLight,
            shape = RoundedCornerShape(14.dp),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(LovraBorder)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Surface(color = LovraPrimary, shape = CircleShape) {
                        Text("1", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp))
                    }
                    Text("Download Telegram", fontWeight = FontWeight.Bold, color = LovraTextPrimary, fontSize = 14.sp)
                }
                Text(
                    text = "Download and install the official Telegram app if you do not already have it on your device.",
                    style = MaterialTheme.typography.bodySmall.copy(color = LovraTextSecondary, fontSize = 12.sp)
                )
                OutlinedButton(
                    onClick = {
                        try {
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://telegram.org/dl"))
                            context.startActivity(intent)
                        } catch (e: Exception) {
                            viewModel.showToast("Cannot launch browser: ${e.message}")
                        }
                    },
                    modifier = Modifier.fillMaxWidth().testTag("open_telegram_button"),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("OPEN TELEGRAM", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }

        // Step 2: Search for LOVRA Bot
        Surface(
            color = LovraSurfaceLight,
            shape = RoundedCornerShape(14.dp),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(LovraBorder)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Surface(color = LovraPrimary, shape = CircleShape) {
                        Text("2", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp))
                    }
                    Text("Search for LOVRA Bot", fontWeight = FontWeight.Bold, color = LovraTextPrimary, fontSize = 14.sp)
                }
                Text(
                    text = "Open Telegram and connect with the official LOVRA monetization bot: @${adminConfig.botUsername}",
                    style = MaterialTheme.typography.bodySmall.copy(color = LovraTextSecondary, fontSize = 12.sp)
                )
                Button(
                    onClick = {
                        try {
                            val botUri = Uri.parse("tg://resolve?domain=${adminConfig.botUsername}")
                            val intent = Intent(Intent.ACTION_VIEW, botUri)
                            context.startActivity(intent)
                        } catch (e: Exception) {
                            // Fallback to web link
                            val webUri = Uri.parse(adminConfig.botUrl)
                            val webIntent = Intent(Intent.ACTION_VIEW, webUri)
                            context.startActivity(webIntent)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = LovraPrimary),
                    modifier = Modifier.fillMaxWidth().testTag("open_lovra_bot_button"),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Send, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("OPEN LOVRA BOT (@${adminConfig.botUsername})", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 12.sp)
                }
            }
        }

        // Step 3 & 4: Start Conversation & Apply for Monetization
        Surface(
            color = LovraSurfaceLight,
            shape = RoundedCornerShape(14.dp),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(LovraBorder)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Surface(color = LovraPrimary, shape = CircleShape) {
                        Text("3 & 4", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                    }
                    Text("Start Conversation & Identify Account", fontWeight = FontWeight.Bold, color = LovraTextPrimary, fontSize = 14.sp)
                }

                Surface(
                    color = LovraSurfaceVariant,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("ACCOUNT IDENTIFICATION FOR MONETIZATION:", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = LovraPrimary)
                        Text("• LOVRA Username: @${currentUser?.username}", fontSize = 12.sp, color = LovraTextPrimary)
                        Text("• LOVRA User ID: ${currentUser?.id}", fontSize = 12.sp, color = LovraTextPrimary)
                        Text("• Creator Name: ${currentUser?.displayName}", fontSize = 12.sp, color = LovraTextPrimary)
                        Text("• Application Status: ${currentUser?.monetizationStatus?.name ?: "DISABLED"}", fontSize = 12.sp, color = LovraTextPrimary)
                    }
                }

                Text(
                    text = "Monetization Activation Fee: ₹599",
                    fontWeight = FontWeight.Black,
                    fontSize = 15.sp,
                    color = LovraPrimary
                )
                Text(
                    text = "A one-time ₹599 payment is required to activate monetization on your LOVRA creator account.",
                    style = MaterialTheme.typography.bodySmall.copy(color = LovraTextSecondary, fontSize = 12.sp)
                )

                if (!stepFourExpanded) {
                    Button(
                        onClick = { stepFourExpanded = true },
                        colors = ButtonDefaults.buttonColors(containerColor = LovraPrimary),
                        modifier = Modifier.fillMaxWidth().testTag("continue_to_payment_button"),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("CONTINUE TO PAYMENT INSTRUCTIONS", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 12.sp)
                    }
                }
            }
        }

        // ==========================================
        // STEP 5: OFFICIAL PAYMENT INSTRUCTIONS & SUBMISSION
        // ==========================================
        if (stepFourExpanded) {
            Surface(
                color = LovraSurfaceLight,
                shape = RoundedCornerShape(16.dp),
                shadowElevation = 2.dp,
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(LovraPrimary)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Surface(color = LovraPrimary, shape = CircleShape) {
                            Text("5", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp))
                        }
                        Text("Official Payment Instructions", fontWeight = FontWeight.Black, color = LovraTextPrimary, fontSize = 15.sp)
                    }

                    Surface(
                        color = LovraPrimary.copy(alpha = 0.08f),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("Payment Amount: ₹599 (One-Time Activation Fee)", fontWeight = FontWeight.Black, color = LovraPrimary, fontSize = 13.sp)
                            Text(
                                text = adminConfig.paymentInstructions,
                                style = MaterialTheme.typography.bodySmall.copy(color = LovraTextPrimary, lineHeight = 18.sp, fontSize = 12.sp)
                            )
                        }
                    }

                    Text(
                        text = "SUBMIT PAYMENT VERIFICATION DETAILS",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = LovraPrimary,
                            letterSpacing = 1.sp
                        )
                    )

                    OutlinedTextField(
                        value = txReference,
                        onValueChange = { txReference = it },
                        label = { Text("Payment Transaction / Reference ID") },
                        placeholder = { Text("e.g. UPI Ref / Bank UTR: 429182379182") },
                        modifier = Modifier.fillMaxWidth().testTag("payment_ref_input"),
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true
                    )

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = paymentDate,
                            onValueChange = { paymentDate = it },
                            label = { Text("Payment Date") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = paymentTime,
                            onValueChange = { paymentTime = it },
                            label = { Text("Payment Time") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            singleLine = true
                        )
                    }

                    OutlinedTextField(
                        value = paymentProofNote,
                        onValueChange = { paymentProofNote = it },
                        label = { Text("Payment Proof Note / Receipt Details") },
                        placeholder = { Text("Paid from HDFC/Google Pay, Account ending in 4102") },
                        modifier = Modifier.fillMaxWidth().testTag("payment_proof_input"),
                        shape = RoundedCornerShape(10.dp),
                        minLines = 2
                    )

                    Button(
                        onClick = {
                            if (txReference.isBlank()) {
                                viewModel.showToast("Please enter a valid Payment Transaction / Reference ID.")
                                return@Button
                            }
                            isSubmitting = true
                            viewModel.submitMonetizationApplication(
                                paymentReference = txReference,
                                paymentDate = paymentDate,
                                paymentTime = paymentTime,
                                paymentProof = paymentProofNote,
                                onSuccess = {
                                    isSubmitting = false
                                }
                            )
                        },
                        enabled = !isSubmitting,
                        colors = ButtonDefaults.buttonColors(containerColor = LovraPrimary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("submit_monetization_app_button")
                    ) {
                        if (isSubmitting) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                        } else {
                            Text("SUBMIT PAYMENT DETAILS FOR VERIFICATION", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}
