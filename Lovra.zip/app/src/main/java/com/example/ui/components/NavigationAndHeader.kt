package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.*
import com.example.viewmodel.PlayerState

@Composable
fun LovraTopHeader(
    title: String = "LOVRA",
    isGuestMode: Boolean = false,
    onAdminClick: () -> Unit,
    onStudioClick: () -> Unit,
    onSignInClick: () -> Unit = {}
) {
    Surface(
        color = LovraSurfaceLight,
        shadowElevation = 1.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.ic_lovra_logo),
                        contentDescription = "LOVRA Logo",
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                    )
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = title,
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 1.2.sp,
                                    color = LovraTextPrimary
                                )
                            )
                            Surface(
                                color = if (isGuestMode) LovraWarning.copy(alpha = 0.15f) else LovraPrimary.copy(alpha = 0.1f),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = if (isGuestMode) "GUEST PREVIEW" else "NETWORK",
                                    modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp),
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = if (isGuestMode) LovraWarning else LovraPrimary,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                            }
                        }
                        Text(
                            text = if (isGuestMode) "Read-only exploration mode" else "Create. Connect. Earn.",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = LovraTextSecondary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Normal
                            )
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (isGuestMode) {
                        Button(
                            onClick = onSignInClick,
                            colors = ButtonDefaults.buttonColors(containerColor = LovraPrimary),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Text("Sign In", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    } else {
                        // Creator Studio Button
                        IconButton(
                            onClick = onStudioClick,
                            modifier = Modifier
                                .size(38.dp)
                                .background(LovraSurfaceVariant, CircleShape)
                                .testTag("creator_studio_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Analytics,
                                contentDescription = "Creator Studio",
                                tint = LovraPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        // Admin Security Panel Button
                        IconButton(
                            onClick = onAdminClick,
                            modifier = Modifier
                                .size(38.dp)
                                .background(LovraSurfaceVariant, CircleShape)
                                .testTag("admin_panel_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.AdminPanelSettings,
                                contentDescription = "Admin Panel",
                                tint = LovraSecondary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LovraBottomBar(
    currentRoute: String,
    onNavigate: (String) -> Unit
) {
    NavigationBar(
        containerColor = LovraSurfaceLight,
        tonalElevation = 3.dp,
        windowInsets = WindowInsets.navigationBars,
        modifier = Modifier.testTag("lovra_bottom_nav")
    ) {
        val items = listOf(
            Triple("home", "Home", Icons.Default.Home),
            Triple("discover", "Discover", Icons.Default.Explore),
            Triple("create", "Create", Icons.Default.AddCircleOutline),
            Triple("messages", "Messages", Icons.Default.ChatBubbleOutline),
            Triple("profile", "Profile", Icons.Default.PersonOutline)
        )

        items.forEach { (route, label, icon) ->
            val selected = currentRoute == route
            NavigationBarItem(
                selected = selected,
                onClick = { onNavigate(route) },
                icon = {
                    Icon(
                        imageVector = icon,
                        contentDescription = label,
                        modifier = Modifier.size(22.dp)
                    )
                },
                label = {
                    Text(
                        text = label,
                        fontSize = 11.sp,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = LovraPrimary,
                    indicatorColor = LovraPrimary.copy(alpha = 0.12f),
                    unselectedIconColor = LovraTextSecondary,
                    selectedTextColor = LovraPrimary,
                    unselectedTextColor = LovraTextSecondary
                ),
                modifier = Modifier.testTag("nav_item_$route")
            )
        }
    }
}

@Composable
fun MiniPlayerBar(
    playerState: PlayerState,
    onTogglePlay: () -> Unit,
    onExpand: () -> Unit
) {
    val story = playerState.story ?: return

    Surface(
        color = LovraSurfaceLight,
        shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp),
        shadowElevation = 8.dp,
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(LovraBorder)),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onExpand() }
            .testTag("mini_player_bar")
    ) {
        Column {
            val progress = if (playerState.totalDurationSeconds > 0) {
                playerState.currentPositionSeconds.toFloat() / playerState.totalDurationSeconds
            } else 0f

            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(3.dp),
                color = LovraPrimary,
                trackColor = LovraSurfaceVariant
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(LovraPrimary.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.GraphicEq,
                            contentDescription = "Playing",
                            tint = LovraPrimary,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.fillMaxWidth(0.85f)) {
                        Text(
                            text = story.title,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.SemiBold,
                                color = LovraTextPrimary
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "${story.channelName} • ${playerState.currentEpisode?.title ?: "Pilot"}",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = LovraTextSecondary
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                IconButton(
                    onClick = onTogglePlay,
                    modifier = Modifier
                        .size(38.dp)
                        .background(LovraPrimary, CircleShape)
                        .testTag("mini_player_toggle")
                ) {
                    Icon(
                        imageVector = if (playerState.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = if (playerState.isPlaying) "Pause" else "Play",
                        tint = Color.White,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        }
    }
}
