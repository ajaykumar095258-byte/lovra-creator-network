package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CreatorMonetizationStatus
import com.example.ui.theme.*
import com.example.viewmodel.LovraViewModel
import com.example.viewmodel.Screen

@Composable
fun CreatorStudioScreen(
    viewModel: LovraViewModel,
    modifier: Modifier = Modifier
) {
    val currentUser by viewModel.currentUser.collectAsState()
    val creatorEarnings by viewModel.creatorEarnings.collectAsState()
    val withdrawals by viewModel.withdrawals.collectAsState()

    val isMonetized = currentUser?.creatorMonetizationEnabled == true ||
            currentUser?.monetizationStatus == CreatorMonetizationStatus.ACTIVE

    val myEarnings = creatorEarnings[currentUser?.id]

    var showWithdrawDialog by remember { mutableStateOf(false) }
    var withdrawAmount by remember { mutableStateOf("") }
    var withdrawUpi by remember { mutableStateOf("creator.payment@upi") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(LovraLightBg)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .padding(bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Header
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            IconButton(
                onClick = { viewModel.navigateBack() },
                modifier = Modifier.testTag("back_button_studio")
            ) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Back",
                    tint = LovraTextPrimary
                )
            }
            Text(
                text = "CREATOR STUDIO",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Black,
                    letterSpacing = 0.5.sp,
                    color = LovraTextPrimary
                )
            )
        }

        // ==========================================
        // MONETIZATION STATUS & CTA SECTION
        // ==========================================
        if (isMonetized) {
            // MONETIZATION ACTIVE BANNER
            Surface(
                color = LovraSuccess.copy(alpha = 0.08f),
                shape = RoundedCornerShape(14.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(LovraSuccess)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(LovraSuccess),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                    }
                    Column {
                        Text(
                            text = "MONETIZATION: ACTIVE ✅",
                            fontWeight = FontWeight.Black,
                            color = LovraSuccess,
                            fontSize = 14.sp
                        )
                        Text(
                            text = "Your account is monetized. Earning from eligible content & qualified views.",
                            fontSize = 11.5.sp,
                            color = LovraTextPrimary
                        )
                    }
                }
            }
        } else {
            // MAIN CTA: MONETIZE YOUR ACCOUNT
            Surface(
                color = LovraSurfaceLight,
                shape = RoundedCornerShape(16.dp),
                shadowElevation = 2.dp,
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(LovraPrimary)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.MonetizationOn, contentDescription = null, tint = LovraPrimary, modifier = Modifier.size(22.dp))
                        Text(
                            text = "MONETIZE YOUR ACCOUNT",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Black,
                                color = LovraTextPrimary
                            )
                        )
                    }

                    Text(
                        text = "Start earning from your content with LOVRA.",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = LovraTextSecondary,
                            fontWeight = FontWeight.Medium
                        )
                    )

                    Text(
                        text = "Creators can use LOVRA for free, upload content for free, grow their audience for free, and earn money after applying for monetization with the ₹599 activation process.",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = LovraTextTertiary,
                            fontSize = 11.sp,
                            lineHeight = 16.sp
                        )
                    )

                    Button(
                        onClick = { viewModel.navigateTo(Screen.MonetizationApply) },
                        colors = ButtonDefaults.buttonColors(containerColor = LovraPrimary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("apply_for_monetization_button")
                    ) {
                        Text(
                            text = "APPLY FOR MONETIZATION",
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            letterSpacing = 0.5.sp
                        )
                    }
                }
            }
        }

        // ==========================================
        // REAL EARNINGS & FINANCIAL LEDGER
        // ==========================================
        Text(
            text = "CREATOR EARNINGS & LEDGER",
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Bold,
                color = LovraPrimary,
                letterSpacing = 1.sp
            )
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Estimated Earnings Card
            Surface(
                color = LovraSurfaceLight,
                shape = RoundedCornerShape(16.dp),
                shadowElevation = 1.dp,
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(LovraBorder)),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Estimated Earnings", color = LovraTextSecondary, fontSize = 11.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "₹${String.format("%.2f", myEarnings?.estimatedEarnings ?: 0.0)}",
                        fontWeight = FontWeight.Black,
                        color = LovraTextPrimary,
                        fontSize = 20.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (isMonetized) "Active cycle" else "Monetization required",
                        color = if (isMonetized) LovraSuccess else LovraTextTertiary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            // Available Balance Card
            Surface(
                color = LovraSurfaceLight,
                shape = RoundedCornerShape(16.dp),
                shadowElevation = 1.dp,
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(LovraBorder)),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Available Balance", color = LovraTextSecondary, fontSize = 11.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "₹${String.format("%.2f", myEarnings?.availableBalance ?: 0.0)}",
                        fontWeight = FontWeight.Black,
                        color = LovraPrimary,
                        fontSize = 20.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (isMonetized) "Ready for payout" else "₹0.00",
                        color = LovraTextTertiary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        // Payout Request Action (Min ₹500)
        Button(
            onClick = {
                withdrawAmount = "${(myEarnings?.availableBalance ?: 0.0).toInt()}"
                showWithdrawDialog = true
            },
            enabled = isMonetized && (myEarnings?.availableBalance ?: 0.0) >= 500.0,
            colors = ButtonDefaults.buttonColors(containerColor = LovraPrimary),
            modifier = Modifier
                .fillMaxWidth()
                .height(46.dp)
                .testTag("request_payout_button"),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(Icons.Default.AccountBalanceWallet, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("Request Payout (Min ₹500)", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 13.sp)
        }

        // ==========================================
        // MONETIZATION ANALYTICS & QUALIFIED VIEWS
        // ==========================================
        Text(
            text = "MONETIZATION ANALYTICS",
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Bold,
                color = LovraPrimary,
                letterSpacing = 1.sp
            )
        )

        Surface(
            color = LovraSurfaceLight,
            shape = RoundedCornerShape(14.dp),
            shadowElevation = 1.dp,
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(LovraBorder)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Qualified Views", color = LovraTextSecondary, fontSize = 13.sp)
                    val qViews = myEarnings?.qualifiedViews ?: 0L
                    Text(
                        text = if (qViews > 0) "$qViews views" else "No qualified views yet.",
                        color = LovraTextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
                Divider(color = LovraDivider)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Watch Duration", color = LovraTextSecondary, fontSize = 13.sp)
                    val watchMins = myEarnings?.watchTimeMinutes ?: 0L
                    Text("${watchMins / 60}h ${watchMins % 60}m", color = LovraTextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
                Divider(color = LovraDivider)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Payout Status", color = LovraTextSecondary, fontSize = 13.sp)
                    Text(
                        text = if (withdrawals.any { it.status == "PENDING_REVIEW" }) "Processing" else "Settled",
                        color = LovraPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }
        }
    }

    // Payout Request Dialog
    if (showWithdrawDialog) {
        AlertDialog(
            onDismissRequest = { showWithdrawDialog = false },
            title = { Text("Request Creator Payout", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Enter withdrawal amount and destination UPI / Bank details:", fontSize = 12.sp)
                    OutlinedTextField(
                        value = withdrawAmount,
                        onValueChange = { withdrawAmount = it },
                        label = { Text("Amount (INR)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = withdrawUpi,
                        onValueChange = { withdrawUpi = it },
                        label = { Text("UPI ID or Bank Details") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amount = withdrawAmount.toDoubleOrNull() ?: 0.0
                        viewModel.submitWithdrawal(amount, withdrawUpi) {
                            showWithdrawDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = LovraPrimary)
                ) {
                    Text("Submit Payout", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showWithdrawDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
