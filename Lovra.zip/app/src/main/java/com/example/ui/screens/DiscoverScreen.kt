package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ContentFormat
import com.example.ui.components.StoryCard
import com.example.ui.theme.*
import com.example.viewmodel.LovraViewModel

@Composable
fun DiscoverScreen(
    viewModel: LovraViewModel,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedFormat by remember { mutableStateOf<ContentFormat?>(null) }
    var selectedTab by remember { mutableStateOf("All") }

    val stories by viewModel.stories.collectAsState()
    val likedIds by viewModel.likedStoryIds.collectAsState()
    val savedIds by viewModel.savedStoryIds.collectAsState()

    val tabs = listOf("All", "Video", "Shorts", "Audio", "Audio + Visual", "Drama", "Anime")

    val filteredStories = remember(stories, searchQuery, selectedFormat, selectedTab) {
        stories.filter { story ->
            val matchQuery = searchQuery.isBlank() ||
                    story.title.contains(searchQuery, ignoreCase = true) ||
                    story.creatorDisplayName.contains(searchQuery, ignoreCase = true) ||
                    story.channelName.contains(searchQuery, ignoreCase = true) ||
                    story.tags.any { it.contains(searchQuery, ignoreCase = true) }

            val matchFormat = when (selectedTab) {
                "Video" -> story.format == ContentFormat.VIDEO
                "Shorts" -> story.format == ContentFormat.SHORTS
                "Audio" -> story.format == ContentFormat.AUDIO
                "Audio + Visual" -> story.format == ContentFormat.AUDIO_VISUAL
                "Drama" -> story.format == ContentFormat.DRAMA
                "Anime" -> story.format == ContentFormat.ANIME
                else -> if (selectedFormat != null) story.format == selectedFormat else true
            }

            matchQuery && matchFormat
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(LovraLightBg)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Global Real Database Search Input
        item {
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("search_stories_input"),
                placeholder = { Text("Search videos, shorts, audio, drama, creators...", color = LovraTextTertiary, fontSize = 13.sp) },
                leadingIcon = {
                    Icon(imageVector = Icons.Default.Search, contentDescription = "Search", tint = LovraPrimary)
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Clear", tint = LovraTextSecondary)
                        }
                    }
                },
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = LovraPrimary,
                    unfocusedBorderColor = LovraBorder,
                    focusedContainerColor = LovraSurfaceLight,
                    unfocusedContainerColor = LovraSurfaceLight,
                    focusedTextColor = LovraTextPrimary,
                    unfocusedTextColor = LovraTextPrimary
                ),
                singleLine = true
            )
        }

        // Discovery Tabs
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                tabs.forEach { tab ->
                    val isSelected = selectedTab == tab
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedTab = tab },
                        label = {
                            Text(
                                text = tab,
                                color = if (isSelected) androidx.compose.ui.graphics.Color.White else LovraTextPrimary,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 12.sp
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = LovraPrimary,
                            containerColor = LovraSurfaceLight
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = isSelected,
                            borderColor = if (isSelected) LovraPrimary else LovraBorder
                        )
                    )
                }
            }
        }

        // Results Section Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${filteredStories.size} MATCHING RESULTS",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = LovraTextSecondary,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.8.sp
                    )
                )

                Text(
                    text = "Server Indexed",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = LovraSuccess,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                )
            }
        }

        if (filteredStories.isEmpty()) {
            item {
                Surface(
                    color = LovraSurfaceLight,
                    shape = RoundedCornerShape(12.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(LovraBorder)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.SearchOff,
                            contentDescription = "No Results",
                            tint = LovraTextTertiary,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "No content yet.",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = LovraTextPrimary
                            )
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "No content matches your search query in the database.",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = LovraTextSecondary
                            )
                        )
                    }
                }
            }
        } else {
            items(filteredStories) { story ->
                StoryCard(
                    story = story,
                    isLiked = likedIds.contains(story.id),
                    isSaved = savedIds.contains(story.id),
                    onClick = { viewModel.openStoryDetail(story) },
                    onLikeClick = { viewModel.toggleLike(story.id) },
                    onSaveClick = { viewModel.toggleSave(story.id) }
                )
            }
        }
    }
}
