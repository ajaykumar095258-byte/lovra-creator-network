package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LovraLightColorScheme = lightColorScheme(
    primary = LovraPrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDBE5FF),
    onPrimaryContainer = Color(0xFF001552),
    secondary = LovraSecondary,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFEDE3FF),
    onSecondaryContainer = Color(0xFF280064),
    tertiary = LovraAccentCyan,
    onTertiary = Color.White,
    background = LovraLightBg,
    onBackground = LovraTextPrimary,
    surface = LovraSurfaceLight,
    onSurface = LovraTextPrimary,
    surfaceVariant = LovraSurfaceVariant,
    onSurfaceVariant = LovraTextSecondary,
    outline = LovraBorder,
    error = LovraError,
    onError = Color.White
)

@Composable
fun LovraTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = LovraLightColorScheme,
        typography = Typography,
        content = content
    )
}
