package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CreatorMonetizationStatus
import com.example.ui.components.StoryCard
import com.example.ui.theme.*
import com.example.viewmodel.LovraViewModel
import com.example.viewmodel.Screen

@Composable
fun ProfileScreen(
    viewModel: LovraViewModel,
    modifier: Modifier = Modifier
) {
    val currentUser by viewModel.currentUser.collectAsState()
    val stories by viewModel.stories.collectAsState()
    val likedIds by viewModel.likedStoryIds.collectAsState()
    val savedIds by viewModel.savedStoryIds.collectAsState()

    var showEditDialog by remember { mutableStateOf(false) }
    var editDisplayName by remember { mutableStateOf(currentUser?.displayName.orEmpty()) }
    var editBio by remember { mutableStateOf(currentUser?.bio.orEmpty()) }
    var editChannelName by remember { mutableStateOf(currentUser?.channelName.orEmpty()) }

    val userStories = remember(stories, currentUser) {
        stories.filter { it.creatorId == currentUser?.id }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(LovraLightBg)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(4.dp))
            // Profile Card Header
            Surface(
                color = LovraSurfaceLight,
                shape = RoundedCornerShape(16.dp),
                shadowElevation = 1.5.dp,
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(LovraBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(76.dp)
                            .clip(CircleShape)
                            .background(Brush.linearGradient(listOf(LovraPrimary, LovraSecondary))),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = currentUser?.displayName?.take(1) ?: "L",
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontWeight = FontWeight.Black,
                                color = Color.White
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = currentUser?.displayName ?: "Creator",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = LovraTextPrimary
                            )
                        )
                        if (currentUser?.isVerified == true) {
                            Icon(
                                imageVector = Icons.Default.Verified,
                                contentDescription = "Verified",
                                tint = LovraPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    Text(
                        text = "@${currentUser?.username} • ${currentUser?.channelName}",
                        style = MaterialTheme.typography.bodySmall.copy(color = LovraPrimary, fontWeight = FontWeight.Medium)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = currentUser?.bio ?: "Storyteller on LOVRA.",
                        style = MaterialTheme.typography.bodyMedium.copy(color = LovraTextSecondary),
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Real Stats Row (Requirement 1: Honest Data Only)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "${currentUser?.followersCount ?: 0}",
                                fontWeight = FontWeight.Bold,
                                color = LovraTextPrimary,
                                fontSize = 16.sp
                            )
                            Text("Followers", color = LovraTextSecondary, fontSize = 11.sp)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "${currentUser?.followingCount ?: 0}",
                                fontWeight = FontWeight.Bold,
                                color = LovraTextPrimary,
                                fontSize = 16.sp
                            )
                            Text("Following", color = LovraTextSecondary, fontSize = 11.sp)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "${userStories.size}",
                                fontWeight = FontWeight.Bold,
                                color = LovraTextPrimary,
                                fontSize = 16.sp
                            )
                            Text("Stories", color = LovraTextSecondary, fontSize = 11.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Actions Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                editDisplayName = currentUser?.displayName.orEmpty()
                                editBio = currentUser?.bio.orEmpty()
                                editChannelName = currentUser?.channelName.orEmpty()
                                showEditDialog = true
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("edit_profile_button"),
                            shape = RoundedCornerShape(20.dp),
                            border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(LovraBorder))
                        ) {
                            Text("Edit", color = LovraTextPrimary, fontSize = 12.sp)
                        }

                        val context = androidx.compose.ui.platform.LocalContext.current
                        OutlinedButton(
                            onClick = {
                                com.example.util.LovraShareUtil.shareCreator(
                                    context = context,
                                    displayName = currentUser?.displayName ?: "Creator",
                                    username = currentUser?.username ?: "creator",
                                    bio = currentUser?.bio.orEmpty()
                                )
                            },
                            modifier = Modifier
                                .weight(1.1f)
                                .testTag("share_profile_button"),
                            shape = RoundedCornerShape(20.dp),
                            border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(LovraBorder))
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(Icons.Default.Share, contentDescription = null, tint = LovraPrimary, modifier = Modifier.size(14.dp))
                                Text("Share", color = LovraTextPrimary, fontSize = 12.sp)
                            }
                        }

                        Button(
                            onClick = { viewModel.navigateTo(Screen.CreatorStudio) },
                            colors = ButtonDefaults.buttonColors(containerColor = LovraPrimary),
                            modifier = Modifier
                                .weight(1.4f)
                                .testTag("open_creator_studio_button"),
                            shape = RoundedCornerShape(20.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(Icons.Default.Analytics, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                Text("Studio", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    if (currentUser?.isGuest == true) {
                        Button(
                            onClick = { viewModel.exitGuestMode() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .testTag("guest_sign_in_from_profile_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = LovraPrimary)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(Icons.Default.AccountCircle, contentDescription = "Sign In", tint = Color.White, modifier = Modifier.size(18.dp))
                                Text("Sign In with Google to Unlock All Features", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    } else {
                        // Sign Out Action (Rule 4: Mandatory Clean Log Out)
                        OutlinedButton(
                            onClick = { viewModel.onSignOut() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("sign_out_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = LovraError),
                            border = ButtonDefaults.outlinedButtonBorder.copy(
                                brush = androidx.compose.ui.graphics.SolidColor(LovraError.copy(alpha = 0.4f))
                            )
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(Icons.Default.Logout, contentDescription = "Log Out", tint = LovraError, modifier = Modifier.size(16.dp))
                                Text("Sign Out of LOVRA", color = LovraError, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
            }
        }

        // Monetization Status Card
        item {
            val status = currentUser?.monetizationStatus ?: CreatorMonetizationStatus.DISABLED
            Surface(
                color = LovraSurfaceLight,
                shape = RoundedCornerShape(14.dp),
                shadowElevation = 1.dp,
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(LovraBorder)),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.navigateTo(Screen.MonetizationApply) }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = when (status) {
                                CreatorMonetizationStatus.ACTIVE -> Icons.Default.CheckCircle
                                CreatorMonetizationStatus.PENDING -> Icons.Default.HourglassTop
                                else -> Icons.Default.MonetizationOn
                            },
                            contentDescription = "Status",
                            tint = when (status) {
                                CreatorMonetizationStatus.ACTIVE -> LovraSuccess
                                CreatorMonetizationStatus.PENDING -> LovraWarning
                                else -> LovraPrimary
                            },
                            modifier = Modifier.size(24.dp)
                        )
                        Column {
                            Text(
                                text = "MONETIZATION: ${status.name}",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = LovraTextPrimary
                                )
                            )
                            Text(
                                text = if (status == CreatorMonetizationStatus.ACTIVE)
                                    "Active • Eligible for qualified view revenue pool."
                                else if (status == CreatorMonetizationStatus.PENDING)
                                    "Payment verification under review by LOVRA admin desk."
                                else
                                    "Monetize Your Account — Apply via official LOVRA bot.",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = LovraTextSecondary,
                                    fontSize = 11.sp
                                )
                            )
                        }
                    }

                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = "Open",
                        tint = LovraTextTertiary
                    )
                }
            }
        }

        // Published Stories Section
        item {
            Text(
                text = "MY PUBLISHED STORIES (${userStories.size})",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = LovraPrimary,
                    letterSpacing = 1.sp
                )
            )
        }

        if (userStories.isEmpty()) {
            item {
                Surface(
                    color = LovraSurfaceLight,
                    shape = RoundedCornerShape(12.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(LovraBorder)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "No content yet.",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = LovraTextPrimary
                            )
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "You haven't published any stories yet. Tap '+' to create your first series.",
                            style = MaterialTheme.typography.bodySmall.copy(color = LovraTextSecondary)
                        )
                    }
                }
            }
        } else {
            items(userStories) { story ->
                StoryCard(
                    story = story,
                    isLiked = likedIds.contains(story.id),
                    isSaved = savedIds.contains(story.id),
                    onClick = { viewModel.openStoryDetail(story) },
                    onLikeClick = { viewModel.toggleLike(story.id) },
                    onSaveClick = { viewModel.toggleSave(story.id) }
                )
            }
        }
    }

    // Edit Profile Dialog
    if (showEditDialog) {
        AlertDialog(
            onDismissRequest = { showEditDialog = false },
            title = { Text("Edit Channel & Profile", color = LovraTextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = editDisplayName,
                        onValueChange = { editDisplayName = it },
                        label = { Text("Display Name") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = LovraTextPrimary,
                            unfocusedTextColor = LovraTextPrimary,
                            focusedBorderColor = LovraPrimary,
                            unfocusedBorderColor = LovraBorder
                        )
                    )
                    OutlinedTextField(
                        value = editBio,
                        onValueChange = { editBio = it },
                        label = { Text("Bio") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = LovraTextPrimary,
                            unfocusedTextColor = LovraTextPrimary,
                            focusedBorderColor = LovraPrimary,
                            unfocusedBorderColor = LovraBorder
                        )
                    )
                    OutlinedTextField(
                        value = editChannelName,
                        onValueChange = { editChannelName = it },
                        label = { Text("Channel Name") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = LovraTextPrimary,
                            unfocusedTextColor = LovraTextPrimary,
                            focusedBorderColor = LovraPrimary,
                            unfocusedBorderColor = LovraBorder
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.updateProfile(editDisplayName, editBio, editChannelName, "")
                        showEditDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = LovraPrimary)
                ) {
                    Text("Save", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditDialog = false }) {
                    Text("Cancel", color = LovraTextSecondary)
                }
            },
            containerColor = LovraSurfaceLight
        )
    }
}
