package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ContentFormat
import com.example.model.CreatorMonetizationStatus
import com.example.ui.components.StoryCard
import com.example.ui.theme.*
import com.example.viewmodel.LovraViewModel
import com.example.viewmodel.Screen

@Composable
fun HomeScreen(
    viewModel: LovraViewModel,
    modifier: Modifier = Modifier
) {
    val stories by viewModel.stories.collectAsState()
    val likedIds by viewModel.likedStoryIds.collectAsState()
    val savedIds by viewModel.savedStoryIds.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()

    val discoverySections = listOf("For You", "Trending", "New", "Shorts", "Audio", "Dramas", "Anime", "Following")
    var selectedSection by remember { mutableStateOf("For You") }

    val filteredStories = remember(stories, selectedSection) {
        when (selectedSection) {
            "Shorts" -> stories.filter { it.format == ContentFormat.SHORTS }
            "Audio" -> stories.filter { it.format == ContentFormat.AUDIO || it.format == ContentFormat.AUDIO_VISUAL }
            "Dramas" -> stories.filter { it.format == ContentFormat.DRAMA }
            "Anime" -> stories.filter { it.format == ContentFormat.ANIME }
            else -> stories
        }
    }

    val featuredStory = stories.firstOrNull { it.isFeatured } ?: stories.firstOrNull()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(LovraLightBg)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Monetization Announcement Banner
        item {
            val isMonetized = currentUser?.creatorMonetizationEnabled == true ||
                    currentUser?.monetizationStatus == CreatorMonetizationStatus.ACTIVE
            Spacer(modifier = Modifier.height(4.dp))
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        if (isMonetized) {
                            viewModel.navigateTo(Screen.CreatorStudio)
                        } else {
                            viewModel.navigateTo(Screen.MonetizationApply)
                        }
                    }
                    .testTag("monetization_banner"),
                shape = RoundedCornerShape(16.dp),
                color = LovraSurfaceLight,
                shadowElevation = 2.dp,
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = Brush.horizontalGradient(listOf(LovraPrimary, LovraSecondary))
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.MonetizationOn,
                                contentDescription = "Monetization",
                                tint = LovraPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = if (isMonetized)
                                    "MONETIZATION: ACTIVE ✅"
                                else
                                    "MONETIZE YOUR ACCOUNT",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 0.8.sp,
                                    color = LovraPrimary
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = if (isMonetized)
                                "Your account is monetized. View your earnings and qualified-view analytics."
                            else
                                "Start earning from your content with LOVRA.",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = LovraTextSecondary,
                                lineHeight = 17.sp
                            )
                        )
                    }

                    Button(
                        onClick = {
                            if (isMonetized) {
                                viewModel.navigateTo(Screen.CreatorStudio)
                            } else {
                                viewModel.navigateTo(Screen.MonetizationApply)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isMonetized) LovraSecondary else LovraPrimary
                        ),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Text(
                            text = if (isMonetized) "Studio" else "APPLY FOR MONETIZATION",
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 11.5.sp
                        )
                    }
                }
            }
        }

        // Section Tabs
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                discoverySections.forEach { section ->
                    val isSelected = selectedSection == section
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedSection = section },
                        label = {
                            Text(
                                text = section,
                                color = if (isSelected) Color.White else LovraTextPrimary,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 12.sp
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = LovraPrimary,
                            containerColor = LovraSurfaceLight
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = isSelected,
                            borderColor = if (isSelected) LovraPrimary else LovraBorder
                        )
                    )
                }
            }
        }

        // Featured Spotlight (Cinematic Hero Card)
        if (featuredStory != null && selectedSection == "For You") {
            item {
                Column {
                    Text(
                        text = "FEATURED SPOTLIGHT",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.2.sp,
                            color = LovraPrimary
                        )
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    StoryCard(
                        story = featuredStory,
                        isLiked = likedIds.contains(featuredStory.id),
                        isSaved = savedIds.contains(featuredStory.id),
                        onClick = { viewModel.openStoryDetail(featuredStory) },
                        onLikeClick = { viewModel.toggleLike(featuredStory.id) },
                        onSaveClick = { viewModel.toggleSave(featuredStory.id) }
                    )
                }
            }
        }

        // Rising Creators Row
        item {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "RISING CREATORS",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.2.sp,
                            color = LovraTextSecondary
                        )
                    )
                    Text(
                        text = "Discover Channels",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = LovraPrimary,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 11.sp
                        )
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                val followingSet by viewModel.followingSet.collectAsState()

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    val sampleCreators = listOf(
                        com.example.model.UserProfile(
                            id = "ajay_creator",
                            username = "ajay_creator",
                            displayName = "Ajay Kumar",
                            email = "",
                            bio = "Director & dark fantasy anime creator.",
                            channelName = "Originals Studio",
                            isCreator = true,
                            isVerified = true,
                            followersCount = 1240
                        ),
                        com.example.model.UserProfile(
                            id = "meera_voice",
                            username = "meera_voice",
                            displayName = "Meera Sharma",
                            email = "",
                            bio = "Audio dramas & suspense thriller podcaster.",
                            channelName = "Midnight Chronicles",
                            isCreator = true,
                            isVerified = true,
                            followersCount = 890
                        ),
                        com.example.model.UserProfile(
                            id = "arjun_anime",
                            username = "arjun_anime",
                            displayName = "Arjun Verma",
                            email = "",
                            bio = "2D animator bringing Indian mythos to life.",
                            channelName = "Vayu Labs",
                            isCreator = true,
                            isVerified = true,
                            followersCount = 2100
                        ),
                        com.example.model.UserProfile(
                            id = "rohit_drama",
                            username = "rohit_drama",
                            displayName = "Rohit Deshmukh",
                            email = "",
                            bio = "Historical audio storytelling with binaural sound.",
                            channelName = "Chitra Katha",
                            isCreator = true,
                            isVerified = false,
                            followersCount = 640
                        )
                    )

                    items(sampleCreators) { creator ->
                        val isFollowing = followingSet.contains(creator.id)
                        Surface(
                            color = LovraSurfaceLight,
                            shape = RoundedCornerShape(16.dp),
                            shadowElevation = 1.dp,
                            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(LovraBorder)),
                            modifier = Modifier
                                .width(170.dp)
                                .testTag("rising_creator_card_${creator.id}")
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                com.example.ui.components.UserProfileAvatar(
                                    displayName = creator.displayName,
                                    size = 52.dp
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = creator.displayName,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = LovraTextPrimary
                                    ),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = creator.channelName,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = LovraPrimary,
                                        fontSize = 11.sp
                                    ),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "${creator.followersCount} followers",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = LovraTextSecondary,
                                        fontSize = 10.sp
                                    )
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                com.example.ui.components.FollowButton(
                                    isFollowing = isFollowing,
                                    onFollowClick = { viewModel.toggleFollow(creator.id) },
                                    creatorId = creator.id,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }
                }
            }
        }

        // Stories Feed Section
        item {
            Text(
                text = "EXPLORE STORIES & EPISODES",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.2.sp,
                    color = LovraTextSecondary
                )
            )
        }

        if (filteredStories.isEmpty()) {
            item {
                Surface(
                    color = LovraSurfaceLight,
                    shape = RoundedCornerShape(12.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(LovraBorder)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.FilterListOff,
                            contentDescription = "Empty",
                            tint = LovraTextTertiary,
                            modifier = Modifier.size(40.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "No content yet.",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = LovraTextPrimary
                            )
                        )
                        Text(
                            text = "No published stories match the '$selectedSection' section right now.",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = LovraTextSecondary
                            )
                        )
                    }
                }
            }
        } else {
            items(filteredStories) { story ->
                StoryCard(
                    story = story,
                    isLiked = likedIds.contains(story.id),
                    isSaved = savedIds.contains(story.id),
                    onClick = { viewModel.openStoryDetail(story) },
                    onLikeClick = { viewModel.toggleLike(story.id) },
                    onSaveClick = { viewModel.toggleSave(story.id) }
                )
            }
        }
    }
}
