package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AdminMonetizationConfig
import com.example.model.MonetizationApplication
import com.example.model.MonetizationApplicationStatus
import com.example.ui.theme.*
import com.example.viewmodel.LovraViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun AdminDashboardScreen(
    viewModel: LovraViewModel,
    modifier: Modifier = Modifier
) {
    var activeAdminTab by remember { mutableStateOf("Monetization Applications") }
    val monetizationApplications by viewModel.monetizationApplications.collectAsState()
    val reports by viewModel.reports.collectAsState()
    val auditLogs by viewModel.auditLogs.collectAsState()
    val adminConfig by viewModel.adminMonetizationConfig.collectAsState()

    var statusFilter by remember { mutableStateOf("Pending") }
    var searchQuery by remember { mutableStateOf("") }

    var selectedAppForReview by remember { mutableStateOf<MonetizationApplication?>(null) }
    var showRejectDialog by remember { mutableStateOf(false) }
    var rejectionReasonInput by remember { mutableStateOf("Payment could not be verified") }

    // Admin Bot Config state
    var editBotUsername by remember { mutableStateOf(adminConfig.botUsername) }
    var editPaymentInstructions by remember { mutableStateOf(adminConfig.paymentInstructions) }

    val adminTabs = listOf("Monetization Applications", "Moderation & Reports", "Audit Logs", "Bot & Payment Config")
    val timeFormat = remember { SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()) }

    val filteredApps = remember(monetizationApplications, statusFilter, searchQuery) {
        monetizationApplications.filter { app ->
            val matchesStatus = when (statusFilter) {
                "Pending" -> app.status == MonetizationApplicationStatus.PENDING
                "Approved" -> app.status == MonetizationApplicationStatus.APPROVED
                "Rejected" -> app.status == MonetizationApplicationStatus.REJECTED
                else -> true
            }
            val q = searchQuery.trim().lowercase()
            val matchesQuery = q.isEmpty() ||
                    app.username.lowercase().contains(q) ||
                    app.creatorId.lowercase().contains(q) ||
                    app.id.lowercase().contains(q) ||
                    app.paymentReference.lowercase().contains(q)
            matchesStatus && matchesQuery
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(LovraLightBg)
            .padding(16.dp),
        contentPadding = PaddingValues(bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                IconButton(
                    onClick = { viewModel.navigateBack() },
                    modifier = Modifier.testTag("back_button_admin")
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Back",
                        tint = LovraTextPrimary
                    )
                }
                Column {
                    Text(
                        text = "LOVRA ADMINISTRATIVE DESK",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Black,
                            letterSpacing = 0.5.sp,
                            color = LovraTextPrimary
                        )
                    )
                    Text(
                        text = "Real-time Telegram alerting • Creator Monetization review • Moderation",
                        style = MaterialTheme.typography.bodySmall.copy(color = LovraPrimary, fontSize = 11.sp)
                    )
                }
            }
        }

        // Tab Selector Row
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                adminTabs.forEach { tab ->
                    val isSelected = activeAdminTab == tab
                    FilterChip(
                        selected = isSelected,
                        onClick = { activeAdminTab = tab },
                        label = {
                            Text(
                                text = tab,
                                color = if (isSelected) Color.White else LovraTextPrimary,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 12.sp
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = LovraPrimary,
                            containerColor = LovraSurfaceLight
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = isSelected,
                            borderColor = if (isSelected) LovraPrimary else LovraBorder
                        )
                    )
                }
            }
        }

        // ==========================================
        // TAB 1: MONETIZATION APPLICATIONS
        // ==========================================
        when (activeAdminTab) {
            "Monetization Applications" -> {
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        // Filters row: Pending, Approved, Rejected, All
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf("Pending", "Approved", "Rejected", "All").forEach { filter ->
                                val isSelected = statusFilter == filter
                                FilterChip(
                                    selected = isSelected,
                                    onClick = { statusFilter = filter },
                                    label = { Text(filter, fontSize = 11.sp) }
                                )
                            }
                        }

                        // Search by Username, Creator ID, Application ID, Transaction ID
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("Search by username, creator ID, app ID, or Tx ID", fontSize = 12.sp) },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { searchQuery = "" }) {
                                        Icon(Icons.Default.Close, contentDescription = "Clear", modifier = Modifier.size(16.dp))
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth().testTag("admin_search_app_input"),
                            shape = RoundedCornerShape(10.dp),
                            singleLine = true
                        )
                    }
                }

                if (filteredApps.isEmpty()) {
                    item {
                        Surface(
                            color = LovraSurfaceLight,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Box(modifier = Modifier.padding(24.dp), contentAlignment = Alignment.Center) {
                                Text("No monetization applications match this filter.", color = LovraTextSecondary, fontSize = 12.sp)
                            }
                        }
                    }
                } else {
                    items(filteredApps) { app ->
                        Surface(
                            color = LovraSurfaceLight,
                            shape = RoundedCornerShape(14.dp),
                            shadowElevation = 1.5.dp,
                            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(LovraBorder)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = "${app.creatorName} (@${app.username})",
                                            fontWeight = FontWeight.Bold,
                                            color = LovraTextPrimary,
                                            fontSize = 14.sp
                                        )
                                        Text(
                                            text = "App ID: ${app.id} • Creator ID: ${app.creatorId}",
                                            color = LovraPrimary,
                                            fontSize = 11.sp
                                        )
                                    }

                                    Surface(
                                        color = when (app.status) {
                                            MonetizationApplicationStatus.APPROVED -> LovraSuccess.copy(alpha = 0.12f)
                                            MonetizationApplicationStatus.REJECTED -> LovraError.copy(alpha = 0.12f)
                                            else -> LovraWarning.copy(alpha = 0.12f)
                                        },
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            text = app.status.name,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = when (app.status) {
                                                    MonetizationApplicationStatus.APPROVED -> LovraSuccess
                                                    MonetizationApplicationStatus.REJECTED -> LovraError
                                                    else -> LovraWarning
                                                },
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 10.sp
                                            )
                                        )
                                    }
                                }

                                Divider(color = LovraDivider)

                                Text(
                                    text = "Transaction ID: ${app.paymentReference}",
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = LovraTextPrimary
                                    )
                                )
                                Text(
                                    text = "Amount: ₹${app.amount} INR • Submitted: ${app.paymentDate} at ${app.paymentTime}",
                                    style = MaterialTheme.typography.bodySmall.copy(color = LovraTextSecondary)
                                )
                                if (app.paymentProof.isNotBlank()) {
                                    Text(
                                        text = "Payment proof/note: \"${app.paymentProof}\"",
                                        style = MaterialTheme.typography.bodySmall.copy(color = LovraTextTertiary, fontSize = 11.sp)
                                    )
                                }
                                if (app.rejectionReason.isNotBlank()) {
                                    Text(
                                        text = "Rejection Reason: ${app.rejectionReason}",
                                        style = MaterialTheme.typography.bodySmall.copy(color = LovraError, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                    )
                                }

                                // Actions for Pending Applications
                                if (app.status == MonetizationApplicationStatus.PENDING) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Button(
                                            onClick = {
                                                viewModel.reviewMonetizationApplication(
                                                    applicationId = app.id,
                                                    approve = true,
                                                    rejectionReason = ""
                                                )
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = LovraSuccess),
                                            modifier = Modifier.weight(1f).testTag("admin_approve_button_${app.id}"),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Text("APPROVE", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                        }

                                        Button(
                                            onClick = {
                                                selectedAppForReview = app
                                                showRejectDialog = true
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = LovraError),
                                            modifier = Modifier.weight(1f).testTag("admin_reject_button_${app.id}"),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Text("REJECT", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // ==========================================
            // TAB 2: MODERATION & REPORTS
            // ==========================================
            "Moderation & Reports" -> {
                if (reports.isEmpty()) {
                    item {
                        Surface(
                            color = LovraSurfaceLight,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Box(modifier = Modifier.padding(24.dp), contentAlignment = Alignment.Center) {
                                Text("No pending moderation reports.", color = LovraTextSecondary, fontSize = 12.sp)
                            }
                        }
                    }
                } else {
                    items(reports) { rep ->
                        Surface(
                            color = LovraSurfaceLight,
                            shape = RoundedCornerShape(14.dp),
                            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(LovraBorder)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "${rep.targetType}: ${rep.targetTitle}",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = LovraTextPrimary
                                    )
                                    Text(rep.status, color = LovraWarning, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                                }
                                Text("Reason: ${rep.reason}", color = LovraError, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                                Text("Details: \"${rep.evidenceDetails}\"", color = LovraTextSecondary, fontSize = 11.sp)
                                Text("Reported by @${rep.reporterName}", color = LovraTextTertiary, fontSize = 10.sp)
                            }
                        }
                    }
                }
            }

            // ==========================================
            // TAB 3: AUDIT LOGS
            // ==========================================
            "Audit Logs" -> {
                if (auditLogs.isEmpty()) {
                    item {
                        Surface(color = LovraSurfaceLight, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                            Box(modifier = Modifier.padding(24.dp), contentAlignment = Alignment.Center) {
                                Text("No audit records.", color = LovraTextSecondary, fontSize = 12.sp)
                            }
                        }
                    }
                } else {
                    items(auditLogs.take(25)) { log ->
                        Surface(
                            color = LovraSurfaceLight,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(log.action, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = LovraPrimary)
                                    Text(timeFormat.format(Date(log.timestamp)), fontSize = 9.sp, color = LovraTextTertiary)
                                }
                                Text("Actor: ${log.actor} • Resource: ${log.resource}", fontSize = 10.sp, color = LovraTextSecondary)
                                Text(log.details, fontSize = 10.sp, color = LovraTextTertiary)
                            }
                        }
                    }
                }
            }

            // ==========================================
            // TAB 4: BOT & PAYMENT CONFIG
            // ==========================================
            "Bot & Payment Config" -> {
                item {
                    Surface(
                        color = LovraSurfaceLight,
                        shape = RoundedCornerShape(14.dp),
                        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(LovraBorder)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text(
                                text = "MONETIZATION BOT CONFIGURATION",
                                fontWeight = FontWeight.Black,
                                fontSize = 13.sp,
                                color = LovraPrimary
                            )
                            Text(
                                text = "Configure official LOVRA bot username and banking instructions displayed to creators.",
                                fontSize = 11.sp,
                                color = LovraTextSecondary
                            )

                            OutlinedTextField(
                                value = editBotUsername,
                                onValueChange = { editBotUsername = it },
                                label = { Text("Official Telegram Bot Username") },
                                placeholder = { Text("LovraCreatorBot") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )

                            OutlinedTextField(
                                value = editPaymentInstructions,
                                onValueChange = { editPaymentInstructions = it },
                                label = { Text("Payment Instructions & Bank/UPI details") },
                                modifier = Modifier.fillMaxWidth(),
                                minLines = 3
                            )

                            Button(
                                onClick = {
                                    viewModel.updateAdminMonetizationConfig(
                                        AdminMonetizationConfig(
                                            activationFeeInr = 599,
                                            botUsername = editBotUsername.trim().removePrefix("@"),
                                            botUrl = "https://t.me/${editBotUsername.trim().removePrefix("@")}",
                                            paymentInstructions = editPaymentInstructions.trim()
                                        )
                                    )
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = LovraPrimary),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Save Monetization Configuration", fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                    }
                }
            }
        }
    }

    // ==========================================
    // REJECTION REASON DIALOG
    // ==========================================
    if (showRejectDialog && selectedAppForReview != null) {
        AlertDialog(
            onDismissRequest = { showRejectDialog = false },
            title = {
                Text("Reject Monetization Application", fontWeight = FontWeight.Bold)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Select or enter rejection reason for @${selectedAppForReview?.username}:", fontSize = 12.sp)

                    val presetReasons = listOf(
                        "Payment could not be verified",
                        "Incorrect amount",
                        "Invalid transaction reference",
                        "Duplicate payment",
                        "Payment proof unclear",
                        "Other"
                    )

                    presetReasons.forEach { reason ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            RadioButton(
                                selected = rejectionReasonInput == reason,
                                onClick = { rejectionReasonInput = reason }
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(reason, fontSize = 12.sp)
                        }
                    }

                    if (rejectionReasonInput == "Other") {
                        OutlinedTextField(
                            value = rejectionReasonInput,
                            onValueChange = { rejectionReasonInput = it },
                            label = { Text("Custom Reason") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        selectedAppForReview?.let { app ->
                            viewModel.reviewMonetizationApplication(
                                applicationId = app.id,
                                approve = false,
                                rejectionReason = rejectionReasonInput
                            )
                        }
                        showRejectDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = LovraError)
                ) {
                    Text("Confirm Rejection", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showRejectDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
