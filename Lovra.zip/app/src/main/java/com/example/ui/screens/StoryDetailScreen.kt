package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ContentFormat
import com.example.ui.theme.*
import com.example.viewmodel.LovraViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun StoryDetailScreen(
    viewModel: LovraViewModel,
    modifier: Modifier = Modifier
) {
    val story = viewModel.selectedStory.collectAsState().value
    val playerState by viewModel.playerState.collectAsState()
    val episodesMap by viewModel.episodes.collectAsState()
    val commentsMap by viewModel.comments.collectAsState()
    val followingSet by viewModel.followingSet.collectAsState()
    val likedIds by viewModel.likedStoryIds.collectAsState()
    val savedIds by viewModel.savedStoryIds.collectAsState()

    if (story == null) {
        Box(modifier = modifier.fillMaxSize().background(LovraLightBg), contentAlignment = Alignment.Center) {
            Text("No content yet.", color = LovraTextPrimary)
        }
        return
    }

    val episodes = episodesMap[story.id] ?: emptyList()
    val comments = commentsMap[story.id] ?: emptyList()
    val isFollowing = followingSet.contains(story.creatorId)
    val isLiked = likedIds.contains(story.id)
    val isSaved = savedIds.contains(story.id)

    var commentInput by remember { mutableStateOf("") }
    var showReportDialog by remember { mutableStateOf(false) }
    var reportReason by remember { mutableStateOf("Copyright / Plagiarism") }
    var reportDetails by remember { mutableStateOf("") }

    val isVideoFormat = story.format == ContentFormat.VIDEO || story.format == ContentFormat.SHORTS || story.format == ContentFormat.DRAMA || story.format == ContentFormat.ANIME
    val timeFormat = remember { SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(LovraLightBg)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Back Header with Report action
        item {
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { viewModel.navigateBack() },
                    modifier = Modifier.testTag("back_button_story_detail")
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Back",
                        tint = LovraTextPrimary
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val context = androidx.compose.ui.platform.LocalContext.current

                    IconButton(
                        onClick = {
                            com.example.util.LovraShareUtil.shareStory(
                                context = context,
                                title = story.title,
                                creatorName = story.creatorDisplayName,
                                storyId = story.id
                            )
                        },
                        modifier = Modifier.testTag("share_story_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "Share Story",
                            tint = LovraPrimary
                        )
                    }

                    IconButton(onClick = { viewModel.toggleSave(story.id) }) {
                        Icon(
                            imageVector = if (isSaved) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                            contentDescription = "Save",
                            tint = if (isSaved) LovraPrimary else LovraTextSecondary
                        )
                    }

                    IconButton(onClick = { showReportDialog = true }) {
                        Icon(
                            imageVector = Icons.Default.Flag,
                            contentDescription = "Report Story",
                            tint = LovraTextTertiary
                        )
                    }
                }
            }
        }

        // Full Interactive Video / Audio Player Console (Requirements 12 & 13)
        item {
            Surface(
                color = LovraSurfaceLight,
                shape = RoundedCornerShape(18.dp),
                shadowElevation = 2.dp,
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(LovraBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Video Viewport / Audio Visualizer Box
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                Brush.linearGradient(
                                    if (isVideoFormat) {
                                        listOf(Color(0xFF0F172A), Color(0xFF1E293B))
                                    } else {
                                        listOf(Color(0xFF1E3A8A), Color(0xFF3B82F6))
                                    }
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = if (isVideoFormat) Icons.Default.PlayCircleOutline else Icons.Default.GraphicEq,
                                contentDescription = "Media Playback",
                                tint = Color.White,
                                modifier = Modifier.size(54.dp)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = if (isVideoFormat) "LOVRA HD ADAPTIVE STREAM" else "LOVRA BINAURAL AUDIO EXPERIENCE",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = Color.White,
                                    letterSpacing = 1.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                            )
                        }

                        // Fullscreen button
                        IconButton(
                            onClick = { /* Fullscreen toggle */ },
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(8.dp)
                        ) {
                            Icon(Icons.Default.Fullscreen, contentDescription = "Fullscreen", tint = Color.White)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = story.title,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = LovraTextPrimary
                        ),
                        modifier = Modifier.align(Alignment.Start)
                    )

                    Text(
                        text = "${playerState.currentEpisode?.title ?: "Episode 1"} • ${story.channelName}",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = LovraPrimary,
                            fontWeight = FontWeight.SemiBold
                        ),
                        modifier = Modifier.align(Alignment.Start)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Media Slider
                    Slider(
                        value = playerState.currentPositionSeconds.toFloat(),
                        onValueChange = { viewModel.seekPlayer(it.toInt()) },
                        valueRange = 0f..playerState.totalDurationSeconds.toFloat(),
                        colors = SliderDefaults.colors(
                            thumbColor = LovraPrimary,
                            activeTrackColor = LovraPrimary,
                            inactiveTrackColor = LovraSurfaceVariant
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Timing labels
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = String.format("%02d:%02d", playerState.currentPositionSeconds / 60, playerState.currentPositionSeconds % 60),
                            color = LovraTextSecondary,
                            fontSize = 11.sp
                        )
                        Text(
                            text = String.format("%02d:%02d", playerState.totalDurationSeconds / 60, playerState.totalDurationSeconds % 60),
                            color = LovraTextSecondary,
                            fontSize = 11.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Player Controls
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { viewModel.seekPlayer(playerState.currentPositionSeconds - 10) }) {
                            Icon(Icons.Default.Replay10, contentDescription = "Back 10s", tint = LovraTextSecondary, modifier = Modifier.size(28.dp))
                        }

                        Box(
                            modifier = Modifier
                                .size(54.dp)
                                .clip(CircleShape)
                                .background(LovraPrimary)
                                .clickable { viewModel.togglePlayerPlayback() },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (playerState.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = if (playerState.isPlaying) "Pause" else "Play",
                                tint = Color.White,
                                modifier = Modifier.size(32.dp)
                            )
                        }

                        IconButton(onClick = { viewModel.seekPlayer(playerState.currentPositionSeconds + 10) }) {
                            Icon(Icons.Default.Forward10, contentDescription = "Forward 10s", tint = LovraTextSecondary, modifier = Modifier.size(28.dp))
                        }
                    }
                }
            }
        }

        // Creator Profile Row & Follow (Enhanced UserProfileCard)
        item {
            val creatorProfile = remember(story) {
                com.example.model.UserProfile(
                    id = story.creatorId,
                    username = story.creatorUsername,
                    displayName = story.creatorDisplayName,
                    email = "",
                    bio = "Creator of ${story.title} on LOVRA",
                    channelName = story.channelName,
                    isCreator = true,
                    isVerified = true
                )
            }
            com.example.ui.components.UserProfileCard(
                user = creatorProfile,
                isFollowing = isFollowing,
                onFollowClick = { viewModel.toggleFollow(story.creatorId) },
                isCompact = true,
                showStats = false
            )
        }

        // Story Synopsis & Tags
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "SYNOPSIS",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = LovraPrimary,
                        letterSpacing = 1.sp
                    )
                )
                Text(
                    text = story.description,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = LovraTextSecondary,
                        lineHeight = 20.sp
                    )
                )

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    story.tags.forEach { tag ->
                        Surface(
                            color = LovraSurfaceVariant,
                            shape = RoundedCornerShape(6.dp),
                            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(LovraBorder))
                        ) {
                            Text("#$tag", color = LovraPrimary, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp))
                        }
                    }
                }

                // Public Canonical Web Link & Open in LOVRA action bar
                val currentStoryContext = androidx.compose.ui.platform.LocalContext.current
                Surface(
                    color = LovraSurfaceVariant.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(8.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(LovraBorder)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "CANONICAL WEB LINK",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = LovraPrimary,
                                    fontSize = 9.sp,
                                    letterSpacing = 0.5.sp
                                )
                            )
                            Text(
                                text = com.example.util.LovraShareUtil.getStoryUrl(story.id),
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = LovraTextSecondary,
                                    fontSize = 11.sp
                                ),
                                maxLines = 1
                            )
                        }
                        FilledTonalButton(
                            onClick = {
                                com.example.util.LovraShareUtil.shareStory(
                                    context = currentStoryContext,
                                    title = story.title,
                                    creatorName = story.creatorDisplayName,
                                    storyId = story.id
                                )
                            },
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Share", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Episodes Section
        item {
            Text(
                text = "EPISODES (${episodes.size})",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = LovraPrimary,
                    letterSpacing = 1.sp
                )
            )
        }

        items(episodes) { ep ->
            val isCurrent = playerState.currentEpisode?.id == ep.id
            Surface(
                color = if (isCurrent) LovraPrimary.copy(alpha = 0.08f) else LovraSurfaceLight,
                shape = RoundedCornerShape(12.dp),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = androidx.compose.ui.graphics.SolidColor(if (isCurrent) LovraPrimary else LovraBorder)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.selectEpisode(ep) }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(if (isCurrent) LovraPrimary else LovraSurfaceVariant),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isCurrent && playerState.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = if (isCurrent) Color.White else LovraTextPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Column {
                            Text(
                                text = "Ep ${ep.episodeNumber}: ${ep.title}",
                                fontWeight = FontWeight.Bold,
                                color = if (isCurrent) LovraPrimary else LovraTextPrimary,
                                fontSize = 13.sp
                            )
                            Text(
                                text = ep.description,
                                color = LovraTextSecondary,
                                fontSize = 11.sp,
                                maxLines = 1
                            )
                        }
                    }

                    Text(
                        text = "${ep.durationSeconds / 60}m",
                        color = LovraTextTertiary,
                        fontSize = 11.sp
                    )
                }
            }
        }

        // Comments Section Header
        item {
            Text(
                text = "COMMENTS & CONVERSATIONS (${comments.size})",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = LovraPrimary,
                    letterSpacing = 1.sp
                )
            )
        }

        // Comment Input Box
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = commentInput,
                    onValueChange = { commentInput = it },
                    placeholder = { Text("Add comment...", color = LovraTextTertiary, fontSize = 12.sp) },
                    modifier = Modifier.weight(1f),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = LovraTextPrimary,
                        unfocusedTextColor = LovraTextPrimary,
                        focusedBorderColor = LovraPrimary,
                        unfocusedBorderColor = LovraBorder,
                        focusedContainerColor = LovraSurfaceLight,
                        unfocusedContainerColor = LovraSurfaceLight
                    ),
                    shape = RoundedCornerShape(20.dp),
                    singleLine = true
                )

                IconButton(
                    onClick = {
                        if (commentInput.isNotBlank()) {
                            viewModel.addComment(story.id, commentInput)
                            commentInput = ""
                        }
                    },
                    modifier = Modifier
                        .size(42.dp)
                        .background(LovraPrimary, CircleShape)
                ) {
                    Icon(Icons.Default.Send, contentDescription = "Send", tint = Color.White, modifier = Modifier.size(18.dp))
                }
            }
        }

        items(comments) { comment ->
            Surface(
                color = LovraSurfaceLight,
                shape = RoundedCornerShape(10.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(LovraBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(comment.displayName, fontWeight = FontWeight.Bold, color = LovraPrimary, fontSize = 12.sp)
                        Text(timeFormat.format(Date(comment.createdAt)), color = LovraTextTertiary, fontSize = 10.sp)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(comment.text, color = LovraTextPrimary, fontSize = 12.sp)
                }
            }
        }
    }

    // Report Dialog
    if (showReportDialog) {
        AlertDialog(
            onDismissRequest = { showReportDialog = false },
            title = { Text("Report Content to Moderation", color = LovraTextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Help keep LOVRA clean and safe for all creators.", color = LovraTextSecondary, fontSize = 12.sp)
                    OutlinedTextField(
                        value = reportReason,
                        onValueChange = { reportReason = it },
                        label = { Text("Reason (Copyright, Spam, Prohibited)") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = LovraTextPrimary,
                            unfocusedTextColor = LovraTextPrimary
                        )
                    )
                    OutlinedTextField(
                        value = reportDetails,
                        onValueChange = { reportDetails = it },
                        label = { Text("Evidence / Details") },
                        minLines = 2,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = LovraTextPrimary,
                            unfocusedTextColor = LovraTextPrimary
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.submitReport("STORY", story.id, story.title, reportReason, reportDetails)
                        showReportDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = LovraError)
                ) {
                    Text("Submit Report", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showReportDialog = false }) {
                    Text("Cancel", color = LovraTextSecondary)
                }
            },
            containerColor = LovraSurfaceLight
        )
    }
}
