package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// LOVRA Warm Premium Soft Light Palette (Requirement 2: Soft off-white / light neutral, not harsh white, distinct surfaces)
val LovraLightBg = Color(0xFFF7F8FC)          // Soft calming off-white background
val LovraSurfaceLight = Color(0xFFFFFFFF)      // Clean card surface
val LovraSurfaceVariant = Color(0xFFEFF2F8)    // Secondary container / chips
val LovraSurfaceElevated = Color(0xFFE4E9F2)   // Elevated cards / headers
val LovraBorder = Color(0xFFDCE2EE)            // Subtle clean borders

// Brand Accents - Modern, youthful, cinematic & trustworthy
val LovraPrimary = Color(0xFF245BFF)          // Deep royal futuristic sapphire blue
val LovraPrimaryVariant = Color(0xFF1440CC)
val LovraSecondary = Color(0xFF7C3AED)        // Vibrant imperial violet/purple
val LovraAccentCyan = Color(0xFF00B4D8)        // Refined cyan
val LovraAccentRose = Color(0xFFE11D48)        // Rich rose accent

// Typography colors with high contrast readability
val LovraTextPrimary = Color(0xFF0F172A)      // Rich dark slate
val LovraTextSecondary = Color(0xFF475569)    // Mid slate
val LovraTextTertiary = Color(0xFF94A3B8)     // Light muted slate

// Functional status
val LovraSuccess = Color(0xFF16A34A)
val LovraWarning = Color(0xFFD97706)
val LovraError = Color(0xFFDC2626)

val LovraCardShadow = Color(0x0F0F172A)
val LovraDivider = Color(0xFFE2E8F0)
