package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ContentFormat
import com.example.ui.theme.*
import com.example.viewmodel.LovraViewModel
import com.example.viewmodel.Screen

@Composable
fun CreateScreen(
    viewModel: LovraViewModel,
    modifier: Modifier = Modifier
) {
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var selectedFormat by remember { mutableStateOf(ContentFormat.VIDEO) }
    var category by remember { mutableStateOf("Drama") }
    var language by remember { mutableStateOf("Hindi / English") }
    var tagsInput by remember { mutableStateOf("Original, Series, HD") }
    var firstEpisodeTitle by remember { mutableStateOf("Episode 1: Premiere") }
    var firstEpisodeTranscript by remember { mutableStateOf("Opening dialogue / production audio cues...") }
    var rightsAgreed by remember { mutableStateOf(false) }

    val categories = listOf("Drama", "Sci-Fi", "Anime & Action", "Shorts", "Mystery", "Romance")

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(LovraLightBg)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .padding(bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        Column {
            Text(
                text = "CREATE & PUBLISH CONTENT",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Black,
                    letterSpacing = 0.5.sp,
                    color = LovraTextPrimary
                )
            )
            Text(
                text = "Publish across Video, Shorts, Audio, Audio+Visuals, Drama, and Anime with automated moderation validation.",
                style = MaterialTheme.typography.bodySmall.copy(color = LovraTextSecondary)
            )
        }

        // Format Selection Grid (6 formats: Video, Shorts, Audio, Audio+Visual, Drama, Anime)
        Text(
            text = "SELECT CONTENT TYPE",
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Bold,
                color = LovraPrimary,
                letterSpacing = 1.sp
            )
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ContentFormat.values().forEach { format ->
                val isSelected = selectedFormat == format
                Surface(
                    color = if (isSelected) LovraPrimary.copy(alpha = 0.1f) else LovraSurfaceLight,
                    shape = RoundedCornerShape(12.dp),
                    border = CardDefaults.outlinedCardBorder().copy(
                        brush = androidx.compose.ui.graphics.SolidColor(if (isSelected) LovraPrimary else LovraBorder)
                    ),
                    modifier = Modifier
                        .width(96.dp)
                        .clickable { selectedFormat = format }
                        .testTag("format_select_${format.name}")
                ) {
                    Column(
                        modifier = Modifier.padding(vertical = 12.dp, horizontal = 6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = when (format) {
                                ContentFormat.VIDEO -> Icons.Default.Videocam
                                ContentFormat.SHORTS -> Icons.Default.Bolt
                                ContentFormat.AUDIO -> Icons.Default.Headphones
                                ContentFormat.AUDIO_VISUAL -> Icons.Default.Subscriptions
                                ContentFormat.DRAMA -> Icons.Default.TheaterComedy
                                ContentFormat.ANIME -> Icons.Default.AutoAwesome
                            },
                            contentDescription = format.label,
                            tint = if (isSelected) LovraPrimary else LovraTextSecondary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = format.label,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) LovraPrimary else LovraTextSecondary,
                                fontSize = 11.sp
                            )
                        )
                    }
                }
            }
        }

        // Title Input
        OutlinedTextField(
            value = title,
            onValueChange = { title = it },
            label = { Text("Title") },
            placeholder = { Text("e.g. Echoes in Neo-Delhi") },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("input_story_title"),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = LovraTextPrimary,
                unfocusedTextColor = LovraTextPrimary,
                focusedBorderColor = LovraPrimary,
                unfocusedBorderColor = LovraBorder,
                focusedContainerColor = LovraSurfaceLight,
                unfocusedContainerColor = LovraSurfaceLight
            ),
            shape = RoundedCornerShape(12.dp)
        )

        // Description Input
        OutlinedTextField(
            value = description,
            onValueChange = { description = it },
            label = { Text("Description & Synopsis") },
            placeholder = { Text("Tell the audience what makes this story captivating...") },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("input_story_desc"),
            minLines = 3,
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = LovraTextPrimary,
                unfocusedTextColor = LovraTextPrimary,
                focusedBorderColor = LovraPrimary,
                unfocusedBorderColor = LovraBorder,
                focusedContainerColor = LovraSurfaceLight,
                unfocusedContainerColor = LovraSurfaceLight
            ),
            shape = RoundedCornerShape(12.dp)
        )

        // Category Picker
        Column {
            Text(
                text = "CATEGORY",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = LovraTextSecondary
                )
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                categories.forEach { cat ->
                    FilterChip(
                        selected = category == cat,
                        onClick = { category = cat },
                        label = { Text(cat, fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = LovraPrimary,
                            selectedLabelColor = Color.White,
                            containerColor = LovraSurfaceLight,
                            labelColor = LovraTextPrimary
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = category == cat,
                            borderColor = if (category == cat) LovraPrimary else LovraBorder
                        )
                    )
                }
            }
        }

        // Language & Tags
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedTextField(
                value = language,
                onValueChange = { language = it },
                label = { Text("Language") },
                modifier = Modifier.weight(1f),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = LovraTextPrimary,
                    unfocusedTextColor = LovraTextPrimary,
                    focusedBorderColor = LovraPrimary,
                    unfocusedBorderColor = LovraBorder,
                    focusedContainerColor = LovraSurfaceLight,
                    unfocusedContainerColor = LovraSurfaceLight
                ),
                shape = RoundedCornerShape(12.dp)
            )

            OutlinedTextField(
                value = tagsInput,
                onValueChange = { tagsInput = it },
                label = { Text("Tags") },
                modifier = Modifier.weight(1.2f),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = LovraTextPrimary,
                    unfocusedTextColor = LovraTextPrimary,
                    focusedBorderColor = LovraPrimary,
                    unfocusedBorderColor = LovraBorder,
                    focusedContainerColor = LovraSurfaceLight,
                    unfocusedContainerColor = LovraSurfaceLight
                ),
                shape = RoundedCornerShape(12.dp)
            )
        }

        // Pilot Episode Details
        Text(
            text = "PILOT / EPISODE 1 SETUP",
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Bold,
                color = LovraPrimary,
                letterSpacing = 1.sp
            )
        )

        OutlinedTextField(
            value = firstEpisodeTitle,
            onValueChange = { firstEpisodeTitle = it },
            label = { Text("Episode Title") },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = LovraTextPrimary,
                unfocusedTextColor = LovraTextPrimary,
                focusedBorderColor = LovraPrimary,
                unfocusedBorderColor = LovraBorder,
                focusedContainerColor = LovraSurfaceLight,
                unfocusedContainerColor = LovraSurfaceLight
            ),
            shape = RoundedCornerShape(12.dp)
        )

        OutlinedTextField(
            value = firstEpisodeTranscript,
            onValueChange = { firstEpisodeTranscript = it },
            label = { Text("Audio Script / Scene Notes") },
            modifier = Modifier.fillMaxWidth(),
            minLines = 2,
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = LovraTextPrimary,
                unfocusedTextColor = LovraTextPrimary,
                focusedBorderColor = LovraPrimary,
                unfocusedBorderColor = LovraBorder,
                focusedContainerColor = LovraSurfaceLight,
                unfocusedContainerColor = LovraSurfaceLight
            ),
            shape = RoundedCornerShape(12.dp)
        )

        // Legal Rights & Ownership confirmation (Requirement 10 & 30)
        Surface(
            color = LovraSurfaceLight,
            shape = RoundedCornerShape(12.dp),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(LovraBorder)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { rightsAgreed = !rightsAgreed }
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Checkbox(
                    checked = rightsAgreed,
                    onCheckedChange = { rightsAgreed = it },
                    colors = CheckboxDefaults.colors(
                        checkedColor = LovraPrimary,
                        uncheckedColor = LovraTextSecondary
                    ),
                    modifier = Modifier.testTag("rights_confirm_checkbox")
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "I own or have licensed all intellectual property rights and permissions to publish this media on LOVRA. No copyright-infringing content.",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = if (rightsAgreed) LovraTextPrimary else LovraTextSecondary,
                        fontSize = 11.sp
                    )
                )
            }
        }

        // Publish Action
        Button(
            onClick = {
                val tags = tagsInput.split(",").map { it.trim() }.filter { it.isNotEmpty() }
                viewModel.publishStory(
                    title = title,
                    description = description,
                    format = selectedFormat,
                    category = category,
                    language = language,
                    tags = tags,
                    epTitle = firstEpisodeTitle,
                    epTranscript = firstEpisodeTranscript,
                    onSuccess = {
                        viewModel.navigateTo(Screen.Home)
                    }
                )
            },
            enabled = title.isNotBlank() && description.isNotBlank() && rightsAgreed,
            colors = ButtonDefaults.buttonColors(containerColor = LovraPrimary),
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .testTag("publish_story_button"),
            shape = RoundedCornerShape(14.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.CloudUpload,
                    contentDescription = "Publish",
                    tint = Color.White
                )
                Text(
                    text = "Publish to LOVRA Network",
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    fontSize = 15.sp
                )
            }
        }
    }
}
