package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.Whatshot
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.sin

private enum class SplashPhase {
    INTRO_CLIP,
    LOVRA_STYLISH_LOADING
}

/**
 * Cinematic Launch Experience:
 * 1. Intro Episode Clip (7s):
 *    - Full-screen responsive dark fantasy anime intro for "AURA : THE POWER OF SHADOW"
 *    - 100% native Compose graphics (immune to Mesa rendernode and Chromium WebGL/GPU crashes)
 *    - Device-adaptive dynamic scaling for any phone or tablet aspect ratio
 *    - 7-second countdown timer with interactive "SKIP INTRO" button
 * 2. Stylish LOVRA Branded Loading:
 *    - Dynamic pulsating LOVRA crest with multi-orbit cosmic rings
 *    - Glowing typography and sleek gradient progress capsule (0% -> 100%)
 *    - Transitions smoothly to the main application
 */
@Composable
fun CinematicLaunchSplash(
    onFinished: () -> Unit
) {
    var phase by remember { mutableStateOf(SplashPhase.INTRO_CLIP) }

    when (phase) {
        SplashPhase.INTRO_CLIP -> {
            CinematicAnimeIntroScreen(
                onIntroComplete = {
                    phase = SplashPhase.LOVRA_STYLISH_LOADING
                }
            )
        }
        SplashPhase.LOVRA_STYLISH_LOADING -> {
            LovraStylishLoadingScreen(
                onLoadingFinished = onFinished
            )
        }
    }
}

/**
 * Full-screen responsive 7-second cinematic episode clip presentation.
 * Uses high-performance native Jetpack Compose animations and canvas rendering,
 * perfectly adapting to all phone, foldable, and tablet aspect ratios.
 */
@Composable
private fun CinematicAnimeIntroScreen(
    onIntroComplete: () -> Unit
) {
    var secondsLeft by remember { mutableIntStateOf(7) }

    // 7-second countdown
    LaunchedEffect(Unit) {
        for (i in 7 downTo 1) {
            secondsLeft = i
            delay(1000)
        }
        secondsLeft = 0
        onIntroComplete()
    }

    // Dynamic animation drivers
    val infiniteTransition = rememberInfiniteTransition(label = "animeAuraPulse")
    
    // Core pulsing scale
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(1100, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    // Cosmic shadow ring rotation
    val shadowRotate by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(8000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shadowRotate"
    )

    val counterRotate by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(12000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "counterRotate"
    )

    // Lightning aura flicker
    val auraGlow by infiniteTransition.animateFloat(
        initialValue = 0.45f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(
            animation = tween(700, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "auraGlow"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF030712)) // Pitch dark void
            .testTag("cinematic_anime_intro_container")
    ) {
        // Dynamic full-screen canvas particles and nebula
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)

            // Deep crimson-violet occult radial field
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0xFFE11D48).copy(alpha = 0.30f * auraGlow),
                        Color(0xFF4C1D95).copy(alpha = 0.25f),
                        Color(0xFF0F172A).copy(alpha = 0.85f),
                        Color(0xFF030712)
                    ),
                    center = center,
                    radius = size.maxDimension * 0.7f
                ),
                center = center,
                radius = size.maxDimension * 0.7f
            )

            // Dynamic geometric shadow wards / runes
            val wardRadius = size.minDimension * 0.42f
            for (i in 0 until 6) {
                val angle = Math.toRadians((shadowRotate + i * 60).toDouble())
                val x = center.x + (wardRadius * cos(angle)).toFloat()
                val y = center.y + (wardRadius * sin(angle)).toFloat()
                drawCircle(
                    color = Color(0xFFE11D48).copy(alpha = 0.4f * auraGlow),
                    radius = 4f,
                    center = Offset(x, y)
                )
            }
        }

        // Top Status Header & Skip Action
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Teaser Badge
            Surface(
                color = Color.Black.copy(alpha = 0.75f),
                shape = RoundedCornerShape(20.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE11D48).copy(alpha = 0.4f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFE11D48))
                    )
                    Text(
                        text = "AURA • DARK FANTASY ANIME",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                }
            }

            // Interactive Skip Button
            Surface(
                onClick = onIntroComplete,
                color = Color(0xFFE11D48).copy(alpha = 0.9f),
                shape = RoundedCornerShape(20.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.35f)),
                modifier = Modifier.testTag("skip_intro_button")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "SKIP (${secondsLeft}s)",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                    Icon(
                        imageVector = Icons.Default.FastForward,
                        contentDescription = "Skip Intro",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }

        // Center Episode Stage: The Power of Shadow Core
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(240.dp)
                    .scale(pulseScale),
                contentAlignment = Alignment.Center
            ) {
                // Outer counter-rotating occult ring
                Box(
                    modifier = Modifier
                        .size(230.dp)
                        .rotate(counterRotate)
                        .border(
                            width = 1.5.dp,
                            brush = Brush.sweepGradient(
                                listOf(
                                    Color(0xFFE11D48),
                                    Color.Transparent,
                                    Color(0xFF818CF8),
                                    Color.Transparent,
                                    Color(0xFF38BDF8),
                                    Color.Transparent,
                                    Color(0xFFE11D48)
                                )
                            ),
                            shape = CircleShape
                        )
                )

                // Middle swirling shadow ring
                Box(
                    modifier = Modifier
                        .size(190.dp)
                        .rotate(shadowRotate)
                        .border(
                            width = 2.5.dp,
                            brush = Brush.sweepGradient(
                                listOf(
                                    Color(0xFFE11D48),
                                    Color(0xFF38BDF8),
                                    Color(0xFF818CF8),
                                    Color(0xFFE11D48)
                                )
                            ),
                            shape = CircleShape
                        )
                )

                // Inner pulsing Shadow Core
                Box(
                    modifier = Modifier
                        .size(140.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                colors = listOf(
                                    Color(0xFFE11D48),
                                    Color(0xFF3B0764),
                                    Color(0xFF09090B)
                                )
                            )
                        )
                        .border(2.dp, Color.White.copy(alpha = 0.25f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    // Shadow silhouette / crest representation
                    Image(
                        painter = painterResource(id = R.drawable.ic_lovra_logo),
                        contentDescription = "Power of Shadow Core",
                        modifier = Modifier
                            .size(92.dp)
                            .clip(CircleShape)
                    )
                }

                // Surrounding Episode Badge
                Surface(
                    color = Color.Black.copy(alpha = 0.85f),
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE11D48)),
                    modifier = Modifier.align(Alignment.BottomCenter)
                ) {
                    Text(
                        text = "EPISODE CLIP • 7 SEC",
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.sp,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            // Main Title
            Text(
                text = "A U R A",
                fontSize = 38.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 8.sp,
                color = Color.White
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "THE POWER OF SHADOW",
                fontSize = 14.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 4.sp,
                color = Color(0xFFE11D48)
            )

            Spacer(modifier = Modifier.height(10.dp))

            Surface(
                color = Color.White.copy(alpha = 0.08f),
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.15f))
            ) {
                Text(
                    text = "COMING SOON • INDIA'S FIRST DARK FANTASY ANIME SERIES",
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFE2E8F0),
                    letterSpacing = 1.sp,
                    textAlign = TextAlign.Center
                )
            }
        }

        // Bottom cinematic subtitle & metadata
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.Transparent,
                            Color.Black.copy(alpha = 0.85f),
                            Color.Black
                        )
                    )
                )
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 16.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                // 7-second time progress capsule
                val progressFraction = (7 - secondsLeft) / 7f
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.6f)
                        .height(3.dp)
                        .clip(RoundedCornerShape(1.5.dp))
                        .background(Color.White.copy(alpha = 0.2f))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(progressFraction)
                            .fillMaxHeight()
                            .background(Color(0xFFE11D48))
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "LOVRA EXCLUSIVE ORIGINAL • AURA CLIP",
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = "Watch the full dark fantasy episode inside LOVRA Creator Universe",
                    color = Color(0xFF94A3B8),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Normal,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

/**
 * Stylish LOVRA Branded Loading Animation:
 * Features high-end dark fantasy anime aesthetics, glowing typography, pulsating emblem,
 * and a smooth gradient loading bar with real-time progress.
 */
@Composable
private fun LovraStylishLoadingScreen(
    onLoadingFinished: () -> Unit
) {
    var progress by remember { mutableFloatStateOf(0f) }
    var currentStatusText by remember { mutableStateOf("✦ Initializing LOVRA Universe...") }

    val infiniteTransition = rememberInfiniteTransition(label = "energyPulse")
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 6000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    val auraGlowScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "auraScale"
    )

    val auraGlowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 0.85f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "auraAlpha"
    )

    // Smooth loading progress progression
    LaunchedEffect(Unit) {
        val steps = listOf(
            0.15f to "✦ Igniting Creator Studio...",
            0.40f to "✦ Loading India's Dark Fantasy Originals...",
            0.75f to "✦ Connecting High-Bitrate Creator Streams...",
            0.95f to "✦ Initializing Feed & Audio Dramas...",
            1.00f to "✦ Welcome to LOVRA Universe"
        )

        for ((targetProg, text) in steps) {
            currentStatusText = text
            val startProg = progress
            val duration = 450
            val startTime = System.currentTimeMillis()
            while (System.currentTimeMillis() - startTime < duration) {
                val fraction = (System.currentTimeMillis() - startTime).toFloat() / duration
                progress = startProg + (targetProg - startProg) * fraction
                delay(16)
            }
            progress = targetProg
            delay(100)
        }

        delay(250)
        onLoadingFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(
                        Color(0xFF1E1B4B), // Deep mystic indigo
                        Color(0xFF0F172A), // Slate midnight
                        Color(0xFF020617)  // Pitch space black
                    )
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding()
            .testTag("lovra_stylish_loading_screen"),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier
                .padding(horizontal = 24.dp)
                .fillMaxWidth()
        ) {
            // Emblem with Rotating Energy Aura
            Box(
                modifier = Modifier.size(150.dp),
                contentAlignment = Alignment.Center
            ) {
                // Pulsing outer energetic aura
                Box(
                    modifier = Modifier
                        .size(144.dp)
                        .scale(auraGlowScale)
                        .alpha(auraGlowAlpha)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                colors = listOf(
                                    Color(0xFFE11D48).copy(alpha = 0.5f), // Crimson fantasy glow
                                    Color(0xFF38BDF8).copy(alpha = 0.4f), // Electric sapphire
                                    Color.Transparent
                                )
                            )
                        )
                )

                // Rotating orbital cosmic ring
                Box(
                    modifier = Modifier
                        .size(136.dp)
                        .rotate(rotationAngle)
                        .border(
                            width = 2.dp,
                            brush = Brush.sweepGradient(
                                colors = listOf(
                                    Color(0xFF38BDF8),
                                    Color(0xFF818CF8),
                                    Color(0xFFE11D48),
                                    Color.Transparent,
                                    Color(0xFF38BDF8)
                                )
                            ),
                            shape = CircleShape
                        )
                )

                // High fidelity LOVRA Crest
                Image(
                    painter = painterResource(id = R.drawable.ic_lovra_logo),
                    contentDescription = "LOVRA Crest",
                    modifier = Modifier
                        .size(100.dp)
                        .clip(CircleShape)
                        .border(2.dp, Color.White.copy(alpha = 0.2f), CircleShape)
                )
            }

            Spacer(modifier = Modifier.height(28.dp))

            // Glowing LOVRA Brand Typography
            Text(
                text = "L O V R A",
                style = MaterialTheme.typography.displaySmall.copy(
                    fontWeight = FontWeight.Black,
                    letterSpacing = 8.sp,
                    fontSize = 38.sp
                ),
                color = Color.White
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Brand Subtitle
            Text(
                text = "CREATOR NETWORK",
                style = MaterialTheme.typography.labelLarge.copy(
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 4.sp,
                    fontSize = 12.sp,
                    color = Color(0xFF38BDF8) // Electric cyan/sapphire
                )
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "ORIGINALS • ANIME • AUDIO DRAMAS • COMMUNITY",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Medium,
                    letterSpacing = 1.5.sp,
                    fontSize = 9.sp,
                    color = Color(0xFF94A3B8)
                )
            )

            Spacer(modifier = Modifier.height(40.dp))

            // High-Tech Sleek Progress Capsule
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.78f)
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(Color.White.copy(alpha = 0.12f))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(progress)
                        .fillMaxHeight()
                        .clip(RoundedCornerShape(3.dp))
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(
                                    Color(0xFF38BDF8), // Electric cyan
                                    Color(0xFF818CF8), // Violet
                                    Color(0xFFE11D48)  // Crimson
                                )
                            )
                        )
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Progress percentage & current loading status message
            Row(
                modifier = Modifier.fillMaxWidth(0.78f),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = currentStatusText,
                    color = Color(0xFFCBD5E1),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1
                )

                Text(
                    text = "${(progress * 100).toInt()}%",
                    color = Color(0xFF38BDF8),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Bottom subtle watermark
            Surface(
                color = Color.White.copy(alpha = 0.06f),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text(
                    text = "AURA : The Power of Shadow • India's 1st Dark Fantasy Series",
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                    color = Color(0xFF64748B),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}
