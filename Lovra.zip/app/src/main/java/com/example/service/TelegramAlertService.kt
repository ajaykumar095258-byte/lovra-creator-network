package com.example.service

/**
 * Backward compatibility alias for TelegramAlertService.
 * Delegates securely to [TelegramNotificationService] without holding any Telegram credentials.
 */
class TelegramAlertService(
    private val notificationService: TelegramNotificationService = TelegramNotificationService()
) {
    suspend fun sendAdminAlert(
        messageText: String,
        buttons: List<List<Pair<String, String>>> = emptyList()
    ): Result<Boolean> {
        return notificationService.sendEventNotification(
            event = "admin_alert",
            messageText = messageText,
            buttons = buttons
        )
    }
}
