package com.example.service

import android.util.Log
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Production-Secure Telegram Notification Service.
 *
 * ARCHITECTURE:
 * Android App -> Secure Backend Endpoint (HTTPS) -> Telegram Bot API -> Telegram Admin
 *
 * SECURITY GUARANTEES:
 * 1. The Telegram Bot Token is NEVER stored, embedded, or referenced in the client APK.
 * 2. The Admin Chat ID is NEVER accepted from or trusted by the client; it is securely managed
 *    on the server environment.
 * 3. Requests to the backend are validated, rate-limited, and authorized via HMAC / API key / Firebase Auth.
 */
class TelegramNotificationService(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()
) {
    companion object {
        private const val TAG = "TelegramNotifyService"
        // Production backend URL; configurable via BuildConfig if present, or defaults to secure proxy
        private const val DEFAULT_BACKEND_URL = "https://api.lovra.app"
    }

    private val backendUrl: String = try {
        val field = BuildConfig::class.java.getField("LOVRA_BACKEND_ALERT_URL")
        (field.get(null) as? String)?.takeIf { it.isNotBlank() } ?: DEFAULT_BACKEND_URL
    } catch (_: Exception) {
        DEFAULT_BACKEND_URL
    }

    private val backendApiKey: String = try {
        val field = BuildConfig::class.java.getField("LOVRA_BACKEND_API_KEY")
        (field.get(null) as? String).orEmpty()
    } catch (_: Exception) {
        ""
    }

    /**
     * Dispatches an event notification to the secure backend.
     * The backend validates the event, attaches server-side credentials, and notifies Telegram.
     */
    suspend fun sendEventNotification(
        event: String,
        messageText: String,
        metadata: Map<String, String> = emptyMap(),
        buttons: List<List<Pair<String, String>>> = emptyList()
    ): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val endpoint = if (backendUrl.endsWith("/")) "${backendUrl}api/telegram/notify" else "$backendUrl/api/telegram/notify"

            val jsonBody = JSONObject().apply {
                put("event", event)
                put("message", messageText)
                put("timestamp", System.currentTimeMillis())

                if (metadata.isNotEmpty()) {
                    val metaObj = JSONObject()
                    metadata.forEach { (k, v) -> metaObj.put(k, v) }
                    put("metadata", metaObj)
                }

                if (buttons.isNotEmpty()) {
                    val inlineKeyboard = JSONArray()
                    for (row in buttons) {
                        val rowArray = JSONArray()
                        for ((text, callbackData) in row) {
                            val btn = JSONObject().apply {
                                put("text", text)
                                put("callback_data", callbackData)
                            }
                            rowArray.put(btn)
                        }
                        inlineKeyboard.put(rowArray)
                    }
                    put("buttons", inlineKeyboard)
                }
            }

            val requestBody = jsonBody.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
            val requestBuilder = Request.Builder()
                .url(endpoint)
                .post(requestBody)
                .addHeader("Content-Type", "application/json")

            if (backendApiKey.isNotBlank()) {
                requestBuilder.addHeader("X-Lovra-Client-Key", backendApiKey)
            }

            client.newCall(requestBuilder.build()).execute().use { response ->
                val responseBody = response.body?.string().orEmpty()
                if (response.isSuccessful) {
                    Log.i(TAG, "Notification delivered to backend: $responseBody")
                    Result.success(true)
                } else {
                    Log.w(TAG, "Backend notification returned [HTTP ${response.code}]: $responseBody")
                    Result.failure(Exception("HTTP ${response.code}: $responseBody"))
                }
            }
        } catch (e: Exception) {
            // Log as non-fatal to avoid degrading user-facing app functions if network/backend is unreachable
            Log.e(TAG, "Exception forwarding notification to backend: ${e.message}")
            Result.failure(e)
        }
    }
}
