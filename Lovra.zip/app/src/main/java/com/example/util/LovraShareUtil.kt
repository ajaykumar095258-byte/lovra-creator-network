package com.example.util

import android.content.Context
import android.content.Intent
import android.net.Uri

object LovraShareUtil {
    const val DOMAIN = "lovra.app"
    const val BASE_URL = "https://$DOMAIN"

    fun getStoryUrl(storyId: String): String = "$BASE_URL/story/$storyId"
    fun getCreatorUrl(creatorUsername: String): String = "$BASE_URL/creator/$creatorUsername"
    fun getDiscoverUrl(): String = "$BASE_URL/discover"
    fun getAudioUrl(): String = "$BASE_URL/audio"
    fun getDramaUrl(): String = "$BASE_URL/drama"
    fun getAnimeUrl(): String = "$BASE_URL/anime"

    fun shareStory(context: Context, title: String, creatorName: String, storyId: String) {
        val url = getStoryUrl(storyId)
        val shareText = "Check out \"$title\" by $creatorName on LOVRA!\n\nOpen in LOVRA: $url"
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "$title on LOVRA")
            putExtra(Intent.EXTRA_TEXT, shareText)
        }
        val chooser = Intent.createChooser(intent, "Share story via")
        context.startActivity(chooser)
    }

    fun shareCreator(context: Context, displayName: String, username: String, bio: String) {
        val url = getCreatorUrl(username)
        val shareText = "Follow $displayName (@$username) on LOVRA – Creator Network!\n$bio\n\nOpen in LOVRA: $url"
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "$displayName on LOVRA")
            putExtra(Intent.EXTRA_TEXT, shareText)
        }
        val chooser = Intent.createChooser(intent, "Share creator profile via")
        context.startActivity(chooser)
    }

    fun openInBrowser(context: Context, url: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            context.startActivity(intent)
        } catch (_: Exception) {}
    }
}
