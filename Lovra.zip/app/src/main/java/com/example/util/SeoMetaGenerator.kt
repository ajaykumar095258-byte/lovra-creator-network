package com.example.util

import com.example.model.StoryItem
import com.example.model.UserProfile

/**
 * Generates SEO-friendly metadata, OpenGraph tags, Twitter Card tags,
 * and JSON-LD structured data for public LOVRA pages.
 */
object SeoMetaGenerator {

    const val DOMAIN = "lovra.app"
    const val BASE_URL = "https://$DOMAIN"
    const val APP_NAME = "LOVRA – Creator Network"
    const val DEFAULT_OG_IMAGE = "https://$DOMAIN/static/lovra-og-banner.png"

    data class PageMeta(
        val title: String,
        val description: String,
        val canonicalUrl: String,
        val ogType: String,
        val ogImage: String,
        val jsonLd: String
    )

    fun forHome(): PageMeta {
        val title = "LOVRA – Creator Network | Audio Stories, Anime & Series"
        val desc = "Explore original stories, dark fantasy anime, creator channels, and episodic dramas on LOVRA."
        val url = "$BASE_URL/"
        val jsonLd = """
            {
              "@context": "https://schema.org",
              "@type": "WebSite",
              "name": "$APP_NAME",
              "url": "$url",
              "potentialAction": {
                "@type": "SearchAction",
                "target": "$BASE_URL/discover?q={search_term_string}",
                "query-input": "required name=search_term_string"
              }
            }
        """.trimIndent()
        return PageMeta(title, desc, url, "website", DEFAULT_OG_IMAGE, jsonLd)
    }

    fun forDiscover(query: String? = null): PageMeta {
        val title = if (query.isNullOrBlank()) "Discover Original Audio, Anime & Stories – LOVRA"
                    else "Search: $query – LOVRA"
        val desc = "Browse trending episodes, dark fantasy series, audiobooks, and rising creators on LOVRA."
        val url = "$BASE_URL/discover"
        val jsonLd = """
            {
              "@context": "https://schema.org",
              "@type": "CollectionPage",
              "name": "$title",
              "description": "$desc",
              "url": "$url"
            }
        """.trimIndent()
        return PageMeta(title, desc, url, "website", DEFAULT_OG_IMAGE, jsonLd)
    }

    fun forStory(story: StoryItem): PageMeta {
        val title = "${story.title} – LOVRA"
        val desc = "Discover ${story.title} by ${story.creatorDisplayName} on LOVRA – Creator Network. ${story.description.take(140)}..."
        val url = "$BASE_URL/story/${story.id}"
        val schemaType = when (story.format.name) {
            "AUDIO", "PODCAST" -> "AudioObject"
            "VIDEO", "DRAMA", "ANIME" -> "VideoObject"
            else -> "CreativeWork"
        }
        val jsonLd = """
            {
              "@context": "https://schema.org",
              "@type": "$schemaType",
              "name": "${escapeJson(story.title)}",
              "description": "${escapeJson(story.description)}",
              "url": "$url",
              "author": {
                "@type": "Person",
                "name": "${escapeJson(story.creatorDisplayName)}",
                "identifier": "${story.creatorUsername}"
              },
              "publisher": {
                "@type": "Organization",
                "name": "$APP_NAME",
                "url": "$BASE_URL"
              }
            }
        """.trimIndent()
        return PageMeta(title, desc, url, "article", DEFAULT_OG_IMAGE, jsonLd)
    }

    fun forCreator(creator: UserProfile): PageMeta {
        val title = "${creator.displayName} (@${creator.username}) – LOVRA Creator"
        val desc = "${creator.bio.ifBlank { "Listen to original audio and watch series by ${creator.displayName} on LOVRA." }}"
        val url = "$BASE_URL/creator/${creator.username}"
        val jsonLd = """
            {
              "@context": "https://schema.org",
              "@type": "Person",
              "name": "${escapeJson(creator.displayName)}",
              "alternateName": "@${escapeJson(creator.username)}",
              "description": "${escapeJson(creator.bio)}",
              "url": "$url"
            }
        """.trimIndent()
        return PageMeta(title, desc, url, "profile", DEFAULT_OG_IMAGE, jsonLd)
    }

    private fun escapeJson(str: String): String {
        return str.replace("\"", "\\\"").replace("\n", " ").replace("\r", "")
    }
}
